(function(){var Q=Object.defineProperty;var ee=(p,e,t)=>e in p?Q(p,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):p[e]=t;var v=(p,e,t)=>ee(p,typeof e!="symbol"?e+"":e,t);const O=[{id:"red",name:"红色",value:"#ef4444"},{id:"orange",name:"橙色",value:"#f97316"},{id:"yellow",name:"黄色",value:"#eab308"},{id:"green",name:"绿色",value:"#22c55e"},{id:"blue",name:"蓝色",value:"#3b82f6"},{id:"purple",name:"紫色",value:"#a855f7"},{id:"pink",name:"粉色",value:"#ec4899"},{id:"gray",name:"灰色",value:"#6b7280"}];function Z(p){if(p&&p.startsWith("#"))return p;const e=O.find(t=>t.id===p);return(e==null?void 0:e.value)??O[7].value}var te=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function se(p){return p&&p.__esModule&&Object.prototype.hasOwnProperty.call(p,"default")?p.default:p}var K={exports:{}};(function(p,e){(function(t,s){s(p)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:te,function(t){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)t.exports=globalThis.browser;else{const s="The message port closed before a response was received.",o=r=>{const n={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(n).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class i extends WeakMap{constructor(c,b=void 0){super(b),this.createItem=c}get(c){return this.has(c)||this.set(c,this.createItem(c)),super.get(c)}}const a=g=>g&&typeof g=="object"&&typeof g.then=="function",l=(g,c)=>(...b)=>{r.runtime.lastError?g.reject(new Error(r.runtime.lastError.message)):c.singleCallbackArg||b.length<=1&&c.singleCallbackArg!==!1?g.resolve(b[0]):g.resolve(b)},d=g=>g==1?"argument":"arguments",u=(g,c)=>function(E,...y){if(y.length<c.minArgs)throw new Error(`Expected at least ${c.minArgs} ${d(c.minArgs)} for ${g}(), got ${y.length}`);if(y.length>c.maxArgs)throw new Error(`Expected at most ${c.maxArgs} ${d(c.maxArgs)} for ${g}(), got ${y.length}`);return new Promise((k,M)=>{if(c.fallbackToNoCallback)try{E[g](...y,l({resolve:k,reject:M},c))}catch(x){console.warn(`${g} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,x),E[g](...y),c.fallbackToNoCallback=!1,c.noCallback=!0,k()}else c.noCallback?(E[g](...y),k()):E[g](...y,l({resolve:k,reject:M},c))})},h=(g,c,b)=>new Proxy(c,{apply(E,y,k){return b.call(y,g,...k)}});let m=Function.call.bind(Object.prototype.hasOwnProperty);const C=(g,c={},b={})=>{let E=Object.create(null),y={has(M,x){return x in g||x in E},get(M,x,L){if(x in E)return E[x];if(!(x in g))return;let T=g[x];if(typeof T=="function")if(typeof c[x]=="function")T=h(g,g[x],c[x]);else if(m(b,x)){let D=u(x,b[x]);T=h(g,g[x],D)}else T=T.bind(g);else if(typeof T=="object"&&T!==null&&(m(c,x)||m(b,x)))T=C(T,c[x],b[x]);else if(m(b,"*"))T=C(T,c[x],b["*"]);else return Object.defineProperty(E,x,{configurable:!0,enumerable:!0,get(){return g[x]},set(D){g[x]=D}}),T;return E[x]=T,T},set(M,x,L,T){return x in E?E[x]=L:g[x]=L,!0},defineProperty(M,x,L){return Reflect.defineProperty(E,x,L)},deleteProperty(M,x){return Reflect.deleteProperty(E,x)}},k=Object.create(g);return new Proxy(k,y)},S=g=>({addListener(c,b,...E){c.addListener(g.get(b),...E)},hasListener(c,b){return c.hasListener(g.get(b))},removeListener(c,b){c.removeListener(g.get(b))}}),I=new i(g=>typeof g!="function"?g:function(b){const E=C(b,{},{getContent:{minArgs:0,maxArgs:0}});g(E)}),H=new i(g=>typeof g!="function"?g:function(b,E,y){let k=!1,M,x=new Promise(F=>{M=function($){k=!0,F($)}}),L;try{L=g(b,E,M)}catch(F){L=Promise.reject(F)}const T=L!==!0&&a(L);if(L!==!0&&!T&&!k)return!1;const D=F=>{F.then($=>{y($)},$=>{let P;$&&($ instanceof Error||typeof $.message=="string")?P=$.message:P="An unexpected error occurred",y({__mozWebExtensionPolyfillReject__:!0,message:P})}).catch($=>{console.error("Failed to send onMessage rejected reply",$)})};return D(T?L:x),!0}),q=({reject:g,resolve:c},b)=>{r.runtime.lastError?r.runtime.lastError.message===s?c():g(new Error(r.runtime.lastError.message)):b&&b.__mozWebExtensionPolyfillReject__?g(new Error(b.message)):c(b)},B=(g,c,b,...E)=>{if(E.length<c.minArgs)throw new Error(`Expected at least ${c.minArgs} ${d(c.minArgs)} for ${g}(), got ${E.length}`);if(E.length>c.maxArgs)throw new Error(`Expected at most ${c.maxArgs} ${d(c.maxArgs)} for ${g}(), got ${E.length}`);return new Promise((y,k)=>{const M=q.bind(null,{resolve:y,reject:k});E.push(M),b.sendMessage(...E)})},f={devtools:{network:{onRequestFinished:S(I)}},runtime:{onMessage:S(H),onMessageExternal:S(H),sendMessage:B.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:B.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},A={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return n.privacy={network:{"*":A},services:{"*":A},websites:{"*":A}},C(r,f,n)};t.exports=o(chrome)}})})(K);var oe=K.exports;const _=se(oe),ne="dvFolderData",J="dvFolderBackup",R="dvAccountId";function re(){try{const p=["token","auth_token","accessToken","userInfo","user_id","accountId"];for(const t of p){const s=localStorage.getItem(t)||sessionStorage.getItem(t);if(s)try{const o=JSON.parse(s);if(o.id)return`user_${o.id}`;if(o.userId)return`user_${o.userId}`;if(o.sub)return`user_${o.sub}`}catch{if(s.length>10&&s.length<200)return`token_${t}_${s.substring(0,50)}`}}const e=document.cookie.split(";");for(const t of e){const[s,o]=t.trim().split("=");if(s&&o&&o.length>10&&o.length<200){if(s.includes("slardar")||s.includes("session")||s.includes("timestamp"))continue;return`cookie_${s}_${o.substring(0,30)}`}}}catch(p){console.warn("[Storage] Failed to get account ID:",p)}return"default"}function G(p){if(typeof p!="object"||p===null)return!1;const e=p;return Array.isArray(e.folders)&&typeof e.folderContents=="object"&&typeof e.starredMessages=="object"&&Array.isArray(e.corpusBoard)&&(e.textHighlights===void 0||Array.isArray(e.textHighlights))}function ie(p,e){try{localStorage.setItem(`${J}_${e}`,JSON.stringify({data:p,timestamp:Date.now(),accountId:e}))}catch(t){console.warn("[Storage] Backup failed:",t)}}function j(p){try{const e=localStorage.getItem(`${J}_${p}`);if(e){const t=JSON.parse(e);if(t.data&&G(t.data))return t.data}}catch(e){console.warn("[Storage] Restore from backup failed:",e)}return null}class ae{constructor(){v(this,"data",{folders:[],folderContents:{},starredMessages:{},corpusBoard:[],textHighlights:[],sectionCollapsed:!1});v(this,"saveTimer",null);v(this,"currentAccountId","")}getStorageKey(){return`${ne}_${this.currentAccountId}`}async init(){this.currentAccountId=re(),console.log("[Storage] Current account:",this.currentAccountId);const e=localStorage.getItem(R);if(e&&e!==this.currentAccountId)console.log("[Storage] Account changed from",e,"to",this.currentAccountId),this.data={folders:[],folderContents:{},starredMessages:{},corpusBoard:[],textHighlights:[]},localStorage.setItem(R,this.currentAccountId),await this.persist(),console.log("[Storage] Cleared data for new account");else{localStorage.setItem(R,this.currentAccountId);try{const t=await _.storage.local.get(this.getStorageKey());if(t[this.getStorageKey()]&&G(t[this.getStorageKey()])){const s=t[this.getStorageKey()];this.data={...s,textHighlights:s.textHighlights??[]},console.log("[Storage] Loaded from chrome.storage for account:",this.currentAccountId)}else{const s=j(this.currentAccountId);s&&(this.data={...s,textHighlights:s.textHighlights??[]},await this.persist(),console.log("[Storage] Restored from localStorage backup"))}}catch(t){console.error("[Storage] Init error:",t);const s=j(this.currentAccountId);s&&(this.data={...s,textHighlights:s.textHighlights??[]})}}}async persist(){ie(this.data,this.currentAccountId);try{await _.storage.local.set({[this.getStorageKey()]:this.data})}catch(e){console.error("[Storage] Save failed:",e)}}debouncedSave(){this.saveTimer&&clearTimeout(this.saveTimer),this.saveTimer=window.setTimeout(()=>{this.persist(),this.saveTimer=null},300)}async getData(){return this.data}async getSectionCollapsed(){return this.data.sectionCollapsed??!1}setSectionCollapsed(e){this.data.sectionCollapsed=e,this.debouncedSave()}async saveFolders(e){this.data.folders=e,this.debouncedSave()}async getFolders(){return this.data.folders}async addFolder(e){this.data.folders.push(e),this.data.folderContents[e.id]=[],this.debouncedSave()}async updateFolder(e,t){const s=this.data.folders.findIndex(o=>o.id===e);s!==-1&&(this.data.folders[s]={...this.data.folders[s],...t,updatedAt:Date.now()},this.debouncedSave())}async deleteFolder(e){this.data.folders=this.data.folders.filter(t=>t.id!==e),delete this.data.folderContents[e],this.debouncedSave()}async addConversationToFolder(e,t){this.data.folderContents[e]||(this.data.folderContents[e]=[]),this.data.folderContents[e].some(o=>o.conversationId===t.conversationId)||(this.data.folderContents[e].push(t),this.debouncedSave())}async removeConversationFromFolder(e,t){this.data.folderContents[e]&&(this.data.folderContents[e]=this.data.folderContents[e].filter(s=>s.conversationId!==t),this.debouncedSave())}async moveConversationBetweenFolders(e,t,s){if(e===t)return;const o=this.data.folderContents[e];if(!o)return;const r=o.findIndex(a=>a.conversationId===s.conversationId);if(r===-1)return;const n=o[r];o.splice(r,1),this.data.folderContents[t]||(this.data.folderContents[t]=[]),this.data.folderContents[t].some(a=>a.conversationId===s.conversationId)||this.data.folderContents[t].push({...n,...s,addedAt:n.addedAt}),this.debouncedSave()}async getConversationFolders(e){const t=[];for(const[s,o]of Object.entries(this.data.folderContents))o.some(r=>r.conversationId===e)&&t.push(s);return t}async getFolderContents(e){return this.data.folderContents[e]??[]}async getStarredMessages(e){return this.data.starredMessages[e]??[]}async addStarredMessage(e,t){this.data.starredMessages[e]||(this.data.starredMessages[e]=[]),this.data.starredMessages[e].includes(t)||(this.data.starredMessages[e].push(t),this.debouncedSave())}async removeStarredMessage(e,t){if(this.data.starredMessages[e]){const s=this.data.starredMessages[e].indexOf(t);s>-1&&(this.data.starredMessages[e].splice(s,1),this.debouncedSave())}}async toggleStarredMessage(e,t){return await this.isMessageStarred(e,t)?(await this.removeStarredMessage(e,t),!1):(await this.addStarredMessage(e,t),!0)}async isMessageStarred(e,t){return(this.data.starredMessages[e]??[]).includes(t)}async getCorpusBoard(){return this.data.corpusBoard}async addToCorpusBoard(e,t,s){const o={id:`corpus_${Date.now()}_${Math.random().toString(36).substr(2,9)}`,text:e,conversationId:t,conversationTitle:s,addedAt:Date.now()};return this.data.corpusBoard.push(o),this.debouncedSave(),o}async removeFromCorpusBoard(e){this.data.corpusBoard=this.data.corpusBoard.filter(t=>t.id!==e),this.debouncedSave()}async clearCorpusBoard(){this.data.corpusBoard=[],this.debouncedSave()}async getTextHighlights(e){return(this.data.textHighlights??[]).filter(t=>t.conversationId===e)}async addTextHighlight(e){const t={...e,id:`highlight_${Date.now()}_${Math.random().toString(36).slice(2,9)}`,createdAt:Date.now()};return this.data.textHighlights||(this.data.textHighlights=[]),this.data.textHighlights.push(t),this.debouncedSave(),t}async updateTextHighlightColor(e,t){var o;const s=(o=this.data.textHighlights)==null?void 0:o.find(r=>r.id===e);s&&(s.color=t,this.debouncedSave())}async removeTextHighlight(e){this.data.textHighlights=(this.data.textHighlights??[]).filter(t=>t.id!==e),this.debouncedSave()}async save(){this.saveTimer&&(clearTimeout(this.saveTimer),this.saveTimer=null),await this.persist()}}const w=new ae;function le(p,e){const t=Z(p.color),s=p.isExpanded;return`
    <div class="dbx-folder-item ${s?"expanded":""}" data-folder-id="${p.id}" data-folder-color="${p.color}">
      <div class="dbx-folder-row" data-folder-id="${p.id}">
        <div class="dbx-folder-expand-icon ${s?"expanded":""}">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 18l6-6-6-6"></path>
          </svg>
        </div>
        <div class="dbx-folder-color-dot" style="background-color: ${t}"></div>
        <span class="dbx-folder-name">${N(p.name)}</span>
        <span class="dbx-folder-count">${e.length}</span>
        <button class="dbx-folder-menu-btn" title="更多操作">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
            <circle cx="12" cy="5" r="1.5"></circle>
            <circle cx="12" cy="12" r="1.5"></circle>
            <circle cx="12" cy="19" r="1.5"></circle>
          </svg>
        </button>
      </div>
      <div class="dbx-folder-contents" data-folder-id="${p.id}">
        ${e.map(o=>de(o)).join("")}
      </div>
    </div>
  `}function de(p){return`
    <div class="dbx-folder-conversation" draggable="true" data-conversation-id="${p.conversationId}">
      <div class="dbx-conversation-icon">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
        </svg>
      </div>
      <span class="dbx-conversation-title">${N(p.title)}</span>
      <button class="dbx-folder-conversation-remove" title="从文件夹移除">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M18 6L6 18M6 6l12 12"></path>
        </svg>
      </button>
    </div>
  `}function ce(){return'<div class="dbx-folder-empty">暂无文件夹</div>'}function ue(){return`
    <div id="dbx-folder-section" class="dbx-folder-section">
      <div class="dbx-folder-header">
        <div class="dbx-folder-title-row">
          <svg class="dbx-folder-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
          </svg>
          <span class="dbx-folder-title">文件夹</span>
        </div>
        <div class="dbx-folder-header-actions">
          <button class="dbx-folder-toggle-btn" title="收起/展开">
            <svg class="dbx-folder-toggle-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M6 9l6 6 6-6"></path>
            </svg>
          </button>
          <button class="dbx-folder-add-btn" title="新建文件夹">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 5v14M5 12h14"></path>
            </svg>
          </button>
        </div>
      </div>
      <div class="dbx-folder-list"></div>
    </div>
  `}function z(p,e){p.addEventListener("dragover",t=>{var s;t.preventDefault(),t.stopPropagation(),p.classList.add("dbx-drop-target"),(s=e.onDragOver)==null||s.call(e,t)}),p.addEventListener("dragleave",t=>{var s;t.preventDefault(),t.stopPropagation(),p.classList.remove("dbx-drop-target"),(s=e.onDragLeave)==null||s.call(e,t)}),p.addEventListener("drop",t=>{t.preventDefault(),t.stopPropagation(),p.classList.remove("dbx-drop-target");const s=p.dataset.folderId;s&&e.onDrop(s)})}function ge(p,e,t){p.draggable=!0,p.addEventListener("dragstart",s=>{p.classList.add("dbx-dragging"),s.dataTransfer&&(s.dataTransfer.effectAllowed="move",s.dataTransfer.setData("application/json",JSON.stringify({type:"conversation",conversationId:e,title:t})))}),p.addEventListener("dragend",()=>{p.classList.remove("dbx-dragging")})}function he(p){const e=document.createElement("div");return e.className="dbx-folder-indicator",e.style.backgroundColor=p,e.style.left="2px",e}function N(p){const e=document.createElement("div");return e.textContent=p,e.innerHTML}class pe{constructor(){v(this,"data",{folders:[],folderContents:{},starredMessages:{},corpusBoard:[]});v(this,"containerElement",null);v(this,"sidebarContainer",null);v(this,"popupElement",null);v(this,"dragData",null);v(this,"initialized",!1);v(this,"sectionCollapsed",!1);this.init=this.init.bind(this),this.render=this.render.bind(this)}async init(){await w.init(),this.data=await w.getData(),this.sectionCollapsed=await w.getSectionCollapsed(),console.log("[FolderManager] Loaded data, folders:",this.data.folders.length),this.data.folders.forEach(e=>e.isExpanded=!1),await this.waitForSidebar(),console.log("[FolderManager] Sidebar ready, creating folder section"),this.findSidebarContainer(),this.setupObservers(),this.containerElement?(console.log("[FolderManager] Container exists, rendering"),this.render()):console.log("[FolderManager] Container not found!"),this.addConversationIndicators(),this.setupFolderDropZones(),this.initialized=!0}waitForSidebar(){return new Promise(e=>{const t=()=>document.querySelector("#flow_chat_sidebar")?(e(),!0):!1;if(t())return;let s=0;const o=100,r=setInterval(()=>{(t()||s>=o)&&(clearInterval(r),s>=o&&console.warn("[FolderManager] Sidebar not found after max retries"),e()),s++},250)})}findSidebarContainer(){this.sidebarContainer=document.querySelector("#flow_chat_sidebar"),this.sidebarContainer&&(this.containerElement=this.sidebarContainer.querySelector("#dbx-folder-section"),this.containerElement?this.setupFolderEvents():this.createFolderSection())}findMoreButtonContainer(){var t;if(!this.sidebarContainer)return null;const e=this.sidebarContainer.querySelectorAll("span.font-medium");for(const s of Array.from(e))if(((t=s.textContent)==null?void 0:t.trim())==="更多"){if(s.closest("#dbx-folder-section"))continue;const o=s.closest('div[data-expand="false"]');if(o)return o;const r=s.closest(".nav-link-IkIer0");return r!=null&&r.parentElement?r.parentElement:r}return null}createFolderSection(){if(!this.sidebarContainer)return;const e=document.createElement("div");e.innerHTML=ue();const t=e.firstElementChild,s=this.findMoreButtonContainer();if(s!=null&&s.parentNode)s.parentNode.insertBefore(t,s.nextSibling);else{const o=this.sidebarContainer.querySelector('[class*="history"]');if(o&&o.parentNode)o.parentNode.insertBefore(t,o.nextSibling);else{const r=this.sidebarContainer.querySelector('[class*="-mx-12"]');r&&r.parentNode?r.parentNode.insertBefore(t,r):this.sidebarContainer.appendChild(t)}}this.containerElement=t,this.setupFolderEvents()}setupFolderEvents(){if(!this.containerElement)return;const e=this.containerElement.querySelector(".dbx-folder-toggle-btn");e&&!e.hasAttribute("data-dv-event-bound")&&(e.setAttribute("data-dv-event-bound","true"),e.addEventListener("click",s=>{s.stopPropagation(),this.toggleSectionCollapsed()}));const t=this.containerElement.querySelector(".dbx-folder-add-btn");t&&!t.hasAttribute("data-dv-event-bound")&&(t.setAttribute("data-dv-event-bound","true"),t.addEventListener("click",s=>{s.stopPropagation(),this.showCreateFolderDialog(t)}))}setupObservers(){let e=null;const t=new MutationObserver(()=>{e&&clearTimeout(e),e=window.setTimeout(()=>{const o=document.querySelector("#flow_chat_sidebar");if(o)if(this.sidebarContainer=o,this.initialized){const r=document.querySelector("#dbx-folder-section");r?(this.containerElement=r,this.setupFolderEvents()):(this.findSidebarContainer(),this.render()),this.addConversationIndicators(),this.setupFolderDropZones()}else this.findSidebarContainer()},100)}),s=document.querySelector("#flow_chat_sidebar");s&&t.observe(s,{childList:!0,subtree:!0})}addConversationIndicators(){document.querySelectorAll('[data-empty-conversation="false"] a[href^="/chat/"]').forEach(t=>{var i;const s=t;if(s.dataset.dvProcessed)return;s.dataset.dvProcessed="true";const o=s.id.match(/conversation_(\d+)/),r=o?o[1]:(i=s.getAttribute("href"))==null?void 0:i.replace("/chat/","");if(!r)return;const n=this.findConversationFolders(r);this.updateConversationIndicator(s,n),this.setupConversationDrag(s,r)}),this.setupFolderDropZones()}updateConversationIndicator(e,t){const s=e.querySelector(".dbx-folder-indicator");if(t.length>0){const o=this.data.folders.find(n=>n.id===t[0]),r=o?Z(o.color):"#6b7280";if(s)s.style.backgroundColor=r;else{const n=he(r),i=e.querySelector(".wrapper-Xy3kj9")||e.querySelector("div:first-child")||e;i&&(i.style.position="relative",i.insertBefore(n,i.firstChild))}}else s&&s.remove()}refreshAllIndicators(){document.querySelectorAll('[data-empty-conversation="false"] a[href^="/chat/"]').forEach(t=>{var i;const s=t,o=s.id.match(/conversation_(\d+)/),r=o?o[1]:(i=s.getAttribute("href"))==null?void 0:i.replace("/chat/","");if(!r)return;const n=this.findConversationFolders(r);this.updateConversationIndicator(s,n)})}setupConversationDrag(e,t){var r;if(e.dataset.dvDraggable==="true")return;e.dataset.dvDraggable="true";const s=e.querySelector('[class*="content"]')||e.querySelector("div"),o=((r=s==null?void 0:s.textContent)==null?void 0:r.trim())||"对话";ge(e,t,o)}setupFolderDropZones(){document.querySelectorAll(".dbx-folder-contents").forEach(t=>{const s=t;if(s.dataset.dvDropZone==="true")return;s.dataset.dvDropZone="true";const o=s.dataset.folderId;o&&z(s,{onDrop:r=>this.handleDrop(r),onDragOver:()=>this.expandFolderOnDrag(o)})})}setupDropZoneForFolderRow(e,t){if(e.dataset.dvDropZoneRow==="true")return;e.dataset.dvDropZoneRow="true";const s=e.querySelector(".dbx-folder-row");s&&z(s,{onDrop:o=>this.handleDrop(o),onDragOver:()=>{e.classList.add("dbx-drop-target"),this.expandFolderOnDrag(t)},onDragLeave:()=>{e.classList.remove("dbx-drop-target")}})}expandFolderOnDrag(e){const t=this.data.folders.find(s=>s.id===e);t&&!t.isExpanded&&(t.isExpanded=!0,this.render())}findConversationFolders(e){const t=[];for(const[s,o]of Object.entries(this.data.folderContents))o.some(r=>r.conversationId===e)&&t.push(s);return t}render(){if(!this.containerElement)return;const e=this.containerElement.querySelector(".dbx-folder-list");if(e){if(this.data.folders.length===0){e.innerHTML=ce();return}e.innerHTML=this.data.folders.map(t=>{const s=this.data.folderContents[t.id]||[];return le(t,s)}).join(""),this.setupFolderElementEvents(),this.setupFolderDropZones(),this.updateSectionCollapseUI()}}setupFolderElementEvents(){var t;const e=(t=this.containerElement)==null?void 0:t.querySelectorAll(".dbx-folder-item");e==null||e.forEach(s=>{const o=s,r=o.dataset.folderId;if(!r)return;const n=o.querySelector(".dbx-folder-row");n&&n.addEventListener("click",a=>{a.target.closest(".dbx-folder-menu-btn")||this.toggleFolder(r)});const i=o.querySelector(".dbx-folder-menu-btn");i==null||i.addEventListener("click",a=>{a.stopPropagation(),this.showFolderMenu(r,i)}),this.setupDropZoneForFolderRow(o,r),o.querySelectorAll(".dbx-folder-conversation").forEach(a=>{const l=a;l.addEventListener("click",u=>{if(u.target.closest(".dbx-folder-conversation-remove"))return;u.stopPropagation();const m=l.dataset.conversationId;m&&(window.location.href=`/chat/${m}`)});const d=l.querySelector(".dbx-folder-conversation-remove");d==null||d.addEventListener("click",u=>{var C;u.stopPropagation();const h=l.dataset.conversationId,m=((C=l.querySelector(".dbx-conversation-title"))==null?void 0:C.textContent)||"对话";h&&this.showRemoveConfirm(r,h,m,d)}),this.setupFolderContentDrag(l,r)})})}setupFolderContentDrag(e,t){e.dataset.dvContentDragBound!=="true"&&(e.dataset.dvContentDragBound="true",e.addEventListener("dragstart",s=>{var n,i;e.classList.add("dbx-dragging");const o=e.dataset.conversationId,r=((i=(n=e.querySelector(".dbx-conversation-title"))==null?void 0:n.textContent)==null?void 0:i.trim())||"对话";s.dataTransfer&&o&&(s.dataTransfer.effectAllowed="move",s.dataTransfer.setData("application/json",JSON.stringify({type:"conversation",conversationId:o,title:r,sourceFolderId:t}))),this.dragData={type:"conversation",conversationId:o,title:r,sourceFolderId:t}}),e.addEventListener("dragend",()=>{e.classList.remove("dbx-dragging"),this.dragData=null}))}showRemoveConfirm(e,t,s,o){var i,a;this.hidePopup();const r=o.getBoundingClientRect(),n=document.createElement("div");n.className="dbx-popup",n.innerHTML=`
      <div class="dbx-popup-content">
        <div class="dbx-popup-title">从文件夹移除</div>
        <div class="dbx-popup-message">确定要将"${N(s)}"从文件夹中移除吗？<br>对话不会被删除，仍在历史记录中。</div>
        <div class="dbx-popup-actions">
          <button class="dbx-popup-btn dbx-popup-btn-cancel">取消</button>
          <button class="dbx-popup-btn dbx-popup-btn-danger">移除</button>
        </div>
      </div>
    `,document.body.appendChild(n),this.popupElement=n,o&&(n.style.cssText=`
        position: fixed;
        left: ${r.left}px;
        top: ${r.bottom+8}px;
        background: transparent;
        display: flex;
        align-items: flex-start;
        justify-content: flex-start;
      `),(i=n.querySelector(".dbx-popup-btn-cancel"))==null||i.addEventListener("click",()=>this.hidePopup()),(a=n.querySelector(".dbx-popup-btn-danger"))==null||a.addEventListener("click",async()=>{await w.removeConversationFromFolder(e,t),this.data=await w.getData(),this.render(),this.refreshAllIndicators(),this.hidePopup()}),n.addEventListener("click",l=>{l.target===n&&this.hidePopup()})}handleDrop(e){var n,i,a;let t="",s="对话",o;const r=document.querySelector(".dbx-dragging");if(r){const l=r.id.match(/conversation_(\d+)/);t=l?l[1]:((n=r.getAttribute("href"))==null?void 0:n.replace("/chat/",""))||"";const d=r.querySelector('[class*="content"]')||r.querySelector("div");s=((i=d==null?void 0:d.textContent)==null?void 0:i.trim())||"对话",o=r.dataset.sourceFolderId||void 0}(a=this.dragData)!=null&&a.conversationId&&(t=this.dragData.conversationId,s=this.dragData.title,o=this.dragData.sourceFolderId),t&&o!==e&&(o?this.moveConversationBetweenFolders(o,e,t,s):this.addConversationToFolder(e,t,s))}async addConversationToFolder(e,t,s){const o={conversationId:t,title:s,url:`/chat/${t}`,addedAt:Date.now()};await w.addConversationToFolder(e,o),this.data=await w.getData(),this.render(),this.refreshAllIndicators()}async moveConversationBetweenFolders(e,t,s,o){const r={conversationId:s,title:o,url:`/chat/${s}`,addedAt:Date.now()};await w.moveConversationBetweenFolders(e,t,r),this.data=await w.getData(),this.render(),this.refreshAllIndicators()}toggleFolder(e){const t=this.data.folders.find(s=>s.id===e);t&&(t.isExpanded=!t.isExpanded,this.render())}toggleSectionCollapsed(){this.sectionCollapsed=!this.sectionCollapsed,this.updateSectionCollapseUI(),w.setSectionCollapsed(this.sectionCollapsed)}updateSectionCollapseUI(){if(!this.containerElement)return;this.containerElement.classList.toggle("collapsed",this.sectionCollapsed);const e=this.containerElement.querySelector(".dbx-folder-toggle-btn");e==null||e.classList.toggle("collapsed",this.sectionCollapsed)}showCreateFolderDialog(e){var a,l,d,u;this.hidePopup();const t=document.createElement("div");if(t.className="dbx-popup",t.innerHTML=`
      <div class="dbx-popup-content">
        <div class="dbx-popup-title">新建文件夹</div>
        <input type="text" class="dbx-popup-input" placeholder="输入文件夹名称" maxlength="20">
        <div class="dbx-popup-color-label">选择颜色</div>
        <div class="dbx-popup-colors">
          ${this.getColorOptionsHTML("blue")}
        </div>
        <div class="dbx-popup-actions">
          <button class="dbx-popup-btn dbx-popup-btn-cancel">取消</button>
          <button class="dbx-popup-btn dbx-popup-btn-confirm">创建</button>
        </div>
      </div>
    `,document.body.appendChild(t),this.popupElement=t,e){const h=e.getBoundingClientRect(),m=280,S=window.innerHeight-h.bottom;let I;S>=m+8?I=h.bottom+8:I=h.top-m-8,t.style.cssText=`
        position: fixed;
        left: ${h.left}px;
        top: ${I}px;
        background: transparent;
        display: flex;
        align-items: flex-start;
        justify-content: flex-start;
      `}const s=t.querySelector(".dbx-popup-input");s==null||s.focus();let o="blue";const r=t.querySelectorAll(".dbx-color-option");r.forEach(h=>{h.addEventListener("click",()=>{r.forEach(m=>m.classList.remove("selected")),h.classList.add("selected"),o=h.dataset.color||"blue"})}),(a=r[0])==null||a.classList.add("selected"),o=((l=r[0])==null?void 0:l.dataset.color)||"blue";const n=t.querySelector(".dbx-color-picker"),i=t.querySelector(".dbx-color-custom");i==null||i.addEventListener("click",h=>{h.stopPropagation(),n==null||n.click()}),n==null||n.addEventListener("input",()=>{r.forEach(h=>h.classList.remove("selected")),i==null||i.classList.add("selected"),i==null||i.classList.add("has-custom-color"),i.style.setProperty("--custom-color",n.value),i.setAttribute("data-color",n.value),o=n.value}),n==null||n.addEventListener("click",h=>{h.stopPropagation()}),(d=t.querySelector(".dbx-popup-btn-cancel"))==null||d.addEventListener("click",()=>this.hidePopup()),(u=t.querySelector(".dbx-popup-btn-confirm"))==null||u.addEventListener("click",async()=>{const h=s.value.trim();if(!h)return;const m={id:`folder_${Date.now()}`,name:h,parentId:null,color:o,isExpanded:!1,createdAt:Date.now(),updatedAt:Date.now()};await w.addFolder(m),this.data=await w.getData(),this.render(),this.hidePopup()}),t.addEventListener("click",h=>{h.target===t&&this.hidePopup()})}getColorOptionsHTML(e){const t=[{id:"blue",value:"#3b82f6"},{id:"green",value:"#22c55e"},{id:"yellow",value:"#eab308"},{id:"orange",value:"#f97316"},{id:"red",value:"#ef4444"},{id:"purple",value:"#a855f7"},{id:"pink",value:"#ec4899"},{id:"gray",value:"#6b7280"}],s=e&&!t.find(n=>n.id===e),o=s?e:"#3b82f6",r=`
      <div class="dbx-color-option dbx-color-custom ${s?"selected":""}" data-color="${o}" style="background-color: ${s?e:"conic-gradient(red, yellow, lime, aqua, blue, magenta, red)"}">
        <input type="color" class="dbx-color-picker" value="${o}">
      </div>
    `;return t.map(n=>`<div class="dbx-color-option ${e===n.id?"selected":""}" data-color="${n.id}" style="background-color: ${n.value}"></div>`).join("")+r}showFolderMenu(e,t){this.hidePopup();const s=this.data.folders.find(i=>i.id===e);if(!s)return;const o=t.getBoundingClientRect(),r=document.createElement("div");r.className="dbx-folder-context-menu",r.style.cssText=`
      position: fixed;
      top: ${o.bottom+4}px;
      left: ${o.left-60}px;
      z-index: 10000;
    `,r.innerHTML=`
      <div class="dbx-folder-menu-item" data-action="rename">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
        </svg>
        <span>重命名</span>
      </div>
      <div class="dbx-folder-menu-item" data-action="color">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="13.5" cy="6.5" r="2.5"></circle>
          <circle cx="17.5" cy="10.5" r="2.5"></circle>
          <circle cx="8.5" cy="7.5" r="2.5"></circle>
          <circle cx="6.5" cy="12.5" r="2.5"></circle>
        </svg>
        <span>更换颜色</span>
      </div>
      <div class="dbx-folder-menu-item danger" data-action="delete">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="3 6 5 6 21 6"></polyline>
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
        </svg>
        <span>删除</span>
      </div>
    `,document.body.appendChild(r),this.popupElement=r,r.querySelectorAll(".dbx-folder-menu-item").forEach(i=>{i.addEventListener("click",async a=>{a.stopPropagation();const l=i.dataset.action;this.hidePopup(),setTimeout(()=>{l==="rename"?this.showRenameDialog(s,t):l==="color"?this.showColorPicker(s,t):l==="delete"&&this.showDeleteConfirm(s,e,t)},50)})});const n=i=>{this.popupElement&&!this.popupElement.contains(i.target)&&this.hidePopup()};setTimeout(()=>{document.addEventListener("click",n,{once:!0})},0)}showRenameDialog(e,t){var r,n;this.hidePopup();const s=document.createElement("div");if(s.className="dbx-popup",s.innerHTML=`
      <div class="dbx-popup-content">
        <div class="dbx-popup-title">重命名文件夹</div>
        <input type="text" class="dbx-popup-input" placeholder="输入新名称" maxlength="20" value="${e.name}">
        <div class="dbx-popup-actions">
          <button class="dbx-popup-btn dbx-popup-btn-cancel">取消</button>
          <button class="dbx-popup-btn dbx-popup-btn-confirm">确定</button>
        </div>
      </div>
    `,document.body.appendChild(s),this.popupElement=s,t){const i=t.getBoundingClientRect();s.style.cssText=`
        position: fixed;
        left: ${i.left}px;
        top: ${i.bottom+8}px;
        background: transparent;
        display: flex;
        align-items: flex-start;
        justify-content: flex-start;
      `}const o=s.querySelector(".dbx-popup-input");o==null||o.focus(),o==null||o.select(),(r=s.querySelector(".dbx-popup-btn-cancel"))==null||r.addEventListener("click",()=>this.hidePopup()),(n=s.querySelector(".dbx-popup-btn-confirm"))==null||n.addEventListener("click",async()=>{const i=o.value.trim();i&&(await w.updateFolder(e.id,{name:i}),this.data=await w.getData(),this.render(),this.hidePopup())}),s.addEventListener("click",i=>{i.target===s&&this.hidePopup()})}showColorPicker(e,t){var l;this.hidePopup();const s=document.createElement("div");if(s.className="dbx-popup",s.innerHTML=`
      <div class="dbx-popup-content">
        <div class="dbx-popup-title">选择颜色</div>
        <div class="dbx-popup-colors dbx-popup-colors-lg">
          ${this.getColorOptionsHTML(e.color)}
        </div>
        <div class="dbx-popup-actions">
          <button class="dbx-popup-btn dbx-popup-btn-cancel">取消</button>
          <button class="dbx-popup-btn dbx-popup-btn-confirm">确定</button>
        </div>
      </div>
    `,document.body.appendChild(s),this.popupElement=s,t){const d=t.getBoundingClientRect();s.style.cssText=`
        position: fixed;
        left: ${d.left}px;
        top: ${d.bottom+8}px;
        background: transparent;
        display: flex;
        align-items: flex-start;
        justify-content: flex-start;
      `}let o=e.color;const r=s.querySelectorAll(".dbx-color-option"),n=s.querySelector(".dbx-color-picker"),i=s.querySelector(".dbx-color-custom");r.forEach(d=>{d.addEventListener("click",async()=>{d.classList.contains("dbx-color-custom")||(r.forEach(u=>u.classList.remove("selected")),d.classList.add("selected"),o=d.dataset.color||e.color,await w.updateFolder(e.id,{color:o}),this.data=await w.getData(),this.render(),this.refreshAllIndicators(),this.hidePopup())})}),i==null||i.addEventListener("click",d=>{d.stopPropagation(),n==null||n.click()}),n==null||n.addEventListener("input",()=>{r.forEach(d=>d.classList.remove("selected")),i==null||i.classList.add("selected"),i==null||i.classList.add("has-custom-color"),i.style.setProperty("--custom-color",n.value),i.setAttribute("data-color",n.value),o=n.value}),n==null||n.addEventListener("click",d=>{d.stopPropagation()});let a=s.querySelector(".dbx-popup-btn-confirm");a==null||a.addEventListener("click",async()=>{await w.updateFolder(e.id,{color:o}),this.data=await w.getData(),this.render(),this.refreshAllIndicators(),this.hidePopup()}),(l=s.querySelector(".dbx-popup-btn-cancel"))==null||l.addEventListener("click",()=>this.hidePopup()),s.addEventListener("click",d=>{d.target===s&&this.hidePopup()})}showDeleteConfirm(e,t,s){var r,n;this.hidePopup();const o=document.createElement("div");if(o.className="dbx-popup",o.innerHTML=`
      <div class="dbx-popup-content">
        <div class="dbx-popup-title">删除文件夹</div>
        <div class="dbx-popup-message">确定要删除"${e.name}"吗？</div>
        <div class="dbx-popup-actions">
          <button class="dbx-popup-btn dbx-popup-btn-cancel">取消</button>
          <button class="dbx-popup-btn dbx-popup-btn-danger">删除</button>
        </div>
      </div>
    `,document.body.appendChild(o),this.popupElement=o,s){const i=s.getBoundingClientRect();o.style.cssText=`
        position: fixed;
        left: ${i.left}px;
        top: ${i.bottom+8}px;
        background: transparent;
        display: flex;
        align-items: flex-start;
        justify-content: flex-start;
      `}else o.style.cssText=`
        position: fixed;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        background: transparent;
        display: flex;
        align-items: center;
        justify-content: center;
      `;(r=o.querySelector(".dbx-popup-btn-cancel"))==null||r.addEventListener("click",()=>this.hidePopup()),(n=o.querySelector(".dbx-popup-btn-danger"))==null||n.addEventListener("click",async()=>{await w.deleteFolder(t),this.data=await w.getData(),this.render(),this.refreshAllIndicators(),this.hidePopup()}),o.addEventListener("click",i=>{i.target===o&&this.hidePopup()})}hidePopup(){this.popupElement&&(this.popupElement.remove(),this.popupElement=null)}destroy(){this.containerElement=null,this.sidebarContainer=null,this.hidePopup()}}const U=new pe;class me{constructor(){v(this,"markers",[]);v(this,"locatorBar",null);v(this,"initialized",!1);v(this,"observer",null);v(this,"starredMarkers",new Set);v(this,"conversationId","unknown");v(this,"tooltipEl",null);v(this,"hideTooltipTimeout",null);v(this,"debounceScan",this.debounce(async()=>{await this.scanMessages(),this.updateLocatorDots()},1e3))}get scrollContainer(){return document.querySelector('[class*="v_list_scroller"], [class*="scroller"], [data-testid="flow_chat_page"], [class*="chat-container"], main, [class*="page-main"]')}init(){this.initialized||(this.conversationId=this.getConversationId(),this.loadStarredMessages(),this.waitForChatContainer(),this.setupUrlChangeListener(),this.initialized=!0)}setupUrlChangeListener(){let e=window.location.href;new MutationObserver(()=>{window.location.href!==e&&(e=window.location.href,this.onConversationChange())}).observe(document.body,{childList:!0,subtree:!0}),setInterval(()=>{window.location.href!==e&&(e=window.location.href,this.onConversationChange())},1e3)}async onConversationChange(){const e=this.getConversationId();e!==this.conversationId&&(this.conversationId=e,this.markers=[],this.locatorBar&&(this.locatorBar.remove(),this.locatorBar=null),await this.loadStarredMessages(),await this.waitForChatContainer())}getConversationId(){const e=window.location.pathname.match(/\/chat\/([^/?#]+)/);return e?e[1]:"unknown"}async waitForChatContainer(){let e=0;const t=30,s=async()=>{const o=this.scrollContainer;if(o||e>=t){o&&(await this.loadStarredMessages(),await this.scanMessages(),this.createLocatorBar(),this.setupObserver());return}e++,setTimeout(s,500)};s()}async loadStarredMessages(){if(!(!this.conversationId||this.conversationId==="unknown"))try{this.starredMarkers=new Set;const e=await w.getStarredMessages(this.conversationId);this.starredMarkers=new Set(e)}catch{}}async scanMessages(){const e=this.scrollContainer;if(!e)return;this.conversationId=this.getConversationId(),await this.loadStarredMessages();const t=[];e.querySelectorAll("[data-message-id]").forEach(o=>{var u;const r=o.closest('.inner-item-BjaxFt, .inner-item-w21SQO, [data-testid="union_message"], [data-testid="message-block-container"]');if(!r)return;const n=((u=r.innerHTML)==null?void 0:u.toLowerCase())||"",i=n.includes("send_message")||n.includes("send-msg")||n.includes("user-bubble")||n.includes("bubble-bg"),a=r.querySelector('.bg-g-send-msg-bubble-bg, [class*="send-msg"], [class*="send_message"], [class*="user-bubble"], [class*="bubble-bg"]');if(i||a){t.push(r);return}const l=r.querySelector('[data-plugin-identifier*="block_type:10052"]'),d=r.querySelector('[class*="justify-end"]');l&&d&&t.push(r)}),this.markers=t.map((o,r)=>{const i=this.extractMessageText(o)||`问题 ${r+1}`;return{id:`marker_${r}`,element:o,text:i,index:r,starred:this.starredMarkers.has(r)}}),this.updateLocatorDots()}extractMessageText(e){var r;const t=e.cloneNode(!0);["svg","button",'[class*="avatar"]','[class*="time"]','[class*="timestamp"]','[class*="meta"]','[class*="action"]','[class*="toolbar"]','[data-testid*="action"]'].forEach(n=>{t.querySelectorAll(n).forEach(i=>i.remove())});let o=((r=t.textContent)==null?void 0:r.trim())||"";return o=o.replace(/\s+/g," ").trim(),!o&&(t.querySelector("img")||t.querySelector('[class*="image"]')||t.querySelector('[data-testid*="image"]')||t.innerHTML.includes("imagex-type"))?"[图片]":o.length>40?o.substring(0,40)+"...":o}createLocatorBar(){if(this.locatorBar)return;const e=document.createElement("div");e.id="dbx-quick-locator",e.innerHTML=`
      <div class="dbx-locator-track"></div>
    `,document.body.appendChild(e),this.locatorBar=e,this.updateLocatorDots()}updateLocatorDots(){if(!this.locatorBar)return;const e=this.locatorBar.querySelector(".dbx-locator-track");e&&(e.innerHTML="",this.markers.forEach((t,s)=>{const o=document.createElement("button");o.className="dbx-locator-dot"+(t.starred?" starred":""),o.setAttribute("data-marker-index",String(s)),o.setAttribute("data-marker-text",t.text),o.addEventListener("mouseenter",r=>{this.showTooltip(r.target,t)}),o.addEventListener("mouseleave",r=>{const n=r.relatedTarget;(!this.tooltipEl||!this.tooltipEl.contains(n))&&this.hideTooltip()}),o.addEventListener("click",()=>{this.scrollToMessage(t)}),e.appendChild(o)}))}showTooltip(e,t){this.hideTooltipTimeout&&(clearTimeout(this.hideTooltipTimeout),this.hideTooltipTimeout=null),this.tooltipEl||(this.tooltipEl=document.createElement("div"),this.tooltipEl.id="dbx-locator-tooltip-floating",this.tooltipEl.style.cssText="position: fixed; z-index: 99999; background: #fff; color: #333; padding: 10px 12px; border-radius: 10px; font-size: 13px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15); width: 240px; height: 90px; display: none; flex-direction: column; gap: 8px; overflow: hidden;",document.body.appendChild(this.tooltipEl),this.tooltipEl.addEventListener("mouseenter",()=>{this.hideTooltipTimeout&&(clearTimeout(this.hideTooltipTimeout),this.hideTooltipTimeout=null)}),this.tooltipEl.addEventListener("mouseleave",()=>{this.hideTooltip()}));const s=this.tooltipEl.querySelector(".tooltip-text");if(s)s.textContent=t.text;else{const n=document.createElement("div");n.className="tooltip-text",n.textContent=t.text,n.style.cssText="color: #333; line-height: 1.4; height: 54px; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; word-wrap: break-word; word-break: break-all;",this.tooltipEl.appendChild(n)}let o=this.tooltipEl.querySelector(".tooltip-star");o||(o=document.createElement("button"),o.className="tooltip-star",o.style.cssText="display: flex; align-items: center; justify-content: flex-start; gap: 6px; padding: 6px 8px; margin: 0 -4px; border-radius: 6px; font-size: 12px; color: #666; cursor: pointer; background: transparent; border: none; width: fit-content;",this.tooltipEl.appendChild(o)),o.innerHTML=`
      <svg width="12" height="12" viewBox="0 0 24 24" fill="${t.starred?"currentColor":"none"}" stroke="currentColor" stroke-width="2">
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
      </svg>
      ${t.starred?"已收藏":"收藏"}
    `,o.onclick=async n=>{var l;n.stopPropagation();const i=!t.starred;o.innerHTML=`
        <svg width="12" height="12" viewBox="0 0 24 24" fill="${i?"currentColor":"none"}" stroke="currentColor" stroke-width="2">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
        </svg>
        ${i?"已收藏":"收藏"}
      `,o.style.color=i?"#f59e0b":"#666";const a=(l=this.locatorBar)==null?void 0:l.querySelector(`[data-marker-index="${t.index}"]`);if(a&&a.classList.toggle("starred",i),this.starredMarkers.has(t.index)?this.starredMarkers.delete(t.index):this.starredMarkers.add(t.index),this.markers[t.index].starred=i,this.conversationId)try{i?await w.addStarredMessage(this.conversationId,t.index):await w.removeStarredMessage(this.conversationId,t.index)}catch{}};const r=e.getBoundingClientRect();this.tooltipEl.style.display="flex",this.tooltipEl.style.left=r.left-240+"px",this.tooltipEl.style.top=r.top+r.height/2-35+"px"}hideTooltip(){this.hideTooltipTimeout||(this.hideTooltipTimeout=window.setTimeout(()=>{this.tooltipEl&&(this.tooltipEl.style.display="none"),this.hideTooltipTimeout=null},150))}scrollToMessage(e){e.element&&(e.element.scrollIntoView({behavior:"smooth",block:"center"}),e.element.classList.add("dbx-message-highlight"),setTimeout(()=>{e.element.classList.remove("dbx-message-highlight")},2e3),this.scrollLocatorToMarker(e.index))}scrollLocatorToMarker(e){var u;const t=(u=this.locatorBar)==null?void 0:u.querySelector(".dbx-locator-track");if(!t)return;const o=t.querySelectorAll(".dbx-locator-dot")[e];if(!o)return;const r=t.getBoundingClientRect(),n=o.getBoundingClientRect(),i=r.height,l=n.top-r.top+n.height/2,d=t.scrollTop+l-i/2;t.scrollTo({top:d,behavior:"smooth"})}setupObserver(){const e=this.scrollContainer;e&&(this.observer=new MutationObserver(t=>{let s=!1;for(const o of t)if(o.addedNodes.length>0){s=!0;break}s&&this.debounceScan()}),this.observer.observe(e,{childList:!0,subtree:!0}))}debounce(e,t){let s=null;return()=>{s&&clearTimeout(s),s=window.setTimeout(e,t)}}destroy(){this.observer&&(this.observer.disconnect(),this.observer=null),this.locatorBar&&(this.locatorBar.remove(),this.locatorBar=null),this.markers=[],this.initialized=!1}}const W=new me;class fe{constructor(){v(this,"triggerBtn",null);v(this,"panel",null);v(this,"initialized",!1);v(this,"isExpanded",!1);v(this,"isDragging",!1);v(this,"dragOffsetX",0);v(this,"dragOffsetY",0);v(this,"positionX",0);v(this,"positionY",0);v(this,"corpusItems",[]);v(this,"highlightObserver",null);v(this,"highlightRestoreTimer",null);v(this,"highlightUrlTimer",null);v(this,"lastHighlightUrl","");v(this,"isRestoringHighlights",!1);v(this,"highlightPaletteResizeHandler",null);v(this,"handleOutsideClick",e=>{this.panel&&!this.panel.contains(e.target)&&this.triggerBtn&&!this.triggerBtn.contains(e.target)&&(this.isExpanded=!1,this.hidePanel())})}init(){this.initialized||(console.log("[CorpusBoard] Initializing..."),this.loadCorpusItems(),this.createTriggerButton(),this.setupTextSelectionListener(),this.setupHighlightPersistence(),this.initialized=!0,console.log("[CorpusBoard] Initialized, trigger button:",this.triggerBtn),setTimeout(()=>{this.recalculatePosition()},2e3))}recalculatePosition(){console.log("[CorpusBoard] Recalculating position after delay...");const e=this.getDefaultPosition();console.log("[CorpusBoard] New default position:",e),console.log("[CorpusBoard] Current position:",{x:this.positionX,y:this.positionY}),console.log("[CorpusBoard] Should update (newPos.x > 1000):",e.x>1e3),e.x>1e3?(this.positionX=e.x,this.positionY=e.y,this.applyTriggerPosition(),console.log("[CorpusBoard] Position updated to:",e)):console.log("[CorpusBoard] Position NOT updated, using current")}async loadCorpusItems(){try{const e=await w.getCorpusBoard(),t=this.getConversationId();this.corpusItems=e.filter(s=>s.conversationId===t)}catch(e){console.error("[CorpusBoard] Failed to load corpus items:",e),this.corpusItems=[]}}createTriggerButton(){var t;if(this.triggerBtn)return;console.log("[CorpusBoard] Creating trigger button..."),console.log("[CorpusBoard] document.body exists:",!!document.body);const e=this.loadPosition();this.positionX=e.x,this.positionY=e.y,this.triggerBtn=document.createElement("div"),this.triggerBtn.id="dbx-corpus-trigger",this.triggerBtn.innerHTML=`
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
        <polyline points="14 2 14 8 20 8"></polyline>
        <line x1="16" y1="13" x2="8" y2="13"></line>
        <line x1="16" y1="17" x2="8" y2="17"></line>
        <polyline points="10 9 9 9 8 9"></polyline>
      </svg>
      <span class="dbx-corpus-count">${this.corpusItems.length}</span>
    `,this.applyTriggerPosition(),this.triggerBtn.style.cssText=this.getTriggerStyles(),this.triggerBtn.style.display="flex",console.log("[CorpusBoard] Trigger button created, in DOM:",(t=document.body)==null?void 0:t.contains(this.triggerBtn)),this.triggerBtn.addEventListener("click",()=>{this.isDragging||this.togglePanel()}),this.setupDrag(),document.body.appendChild(this.triggerBtn),console.log("[CorpusBoard] Trigger button appended to body")}getTriggerStyles(){return`
      position: fixed;
      z-index: 9998;
      width: 44px;
      height: 44px;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 2px 12px rgba(0, 0, 0, 0.15);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: grab;
      color: #666;
      transition: box-shadow 0.2s, transform 0.1s;
      user-select: none;
    `}applyTriggerPosition(){this.triggerBtn&&(this.triggerBtn.style.right="auto",this.triggerBtn.style.bottom="auto",this.triggerBtn.style.left=`${this.positionX}px`,this.triggerBtn.style.top=`${this.positionY}px`)}getDefaultPosition(){console.log("[CorpusBoard] Calculating default position...");const e=this.findInputArea();if(console.log("[CorpusBoard] inputArea found:",!!e),e){const o=e.getBoundingClientRect();return console.log("[CorpusBoard] inputArea rect:",o),{x:o.right+16,y:o.top}}const t=document.querySelector("#dbx-quick-locator");if(console.log("[CorpusBoard] locatorBar found:",!!t),t){const o=t.getBoundingClientRect();return console.log("[CorpusBoard] locatorBar rect:",o),{x:o.right+16,y:o.top}}const s={x:window.innerWidth-70,y:window.innerHeight-200};return console.log("[CorpusBoard] Using fallback position:",s),s}loadPosition(){const e=this.getDefaultPosition();console.log("[CorpusBoard] Default position calculated:",e);try{const t=localStorage.getItem("dbx_corpus_trigger_pos");if(console.log("[CorpusBoard] Loaded position from localStorage:",t),t){const s=JSON.parse(t),o=e.x>1e3;if(s.x>=0&&s.x<window.innerWidth&&s.y>=0&&s.y<window.innerHeight)return o?(console.log("[CorpusBoard] Default is near QuickLocator, using default position"),e):(console.log("[CorpusBoard] Using saved position:",s),s);console.log("[CorpusBoard] Saved position out of bounds, recalculating"),localStorage.removeItem("dbx_corpus_trigger_pos")}}catch(t){console.log("[CorpusBoard] Error loading position:",t)}return console.log("[CorpusBoard] Using default position"),e}savePosition(){try{localStorage.setItem("dbx_corpus_trigger_pos",JSON.stringify({x:this.positionX,y:this.positionY}))}catch{}}setupDrag(){if(!this.triggerBtn)return;const e=t=>{if(this.isExpanded){t.preventDefault();return}if(t.target.closest(".dbx-corpus-panel"))return;this.isDragging=!1;const o=t.clientX,r=t.clientY,n=this.triggerBtn.getBoundingClientRect();this.dragOffsetX=o-n.left,this.dragOffsetY=r-n.top;const i=l=>{const d=Math.abs(l.clientX-o),u=Math.abs(l.clientY-r);(d>5||u>5)&&(this.isDragging=!0),this.isDragging&&(this.positionX=l.clientX-this.dragOffsetX,this.positionY=l.clientY-this.dragOffsetY,this.applyTriggerPosition())},a=()=>{document.removeEventListener("mousemove",i),document.removeEventListener("mouseup",a),this.isDragging&&this.savePosition()};document.addEventListener("mousemove",i),document.addEventListener("mouseup",a)};this.triggerBtn.addEventListener("mousedown",e)}togglePanel(){this.isExpanded=!this.isExpanded,this.isExpanded?(this.createPanel(),this.updatePanelContent()):this.hidePanel()}createPanel(){this.panel||(this.panel=document.createElement("div"),this.panel.className="dbx-corpus-panel",this.panel.style.cssText=this.getPanelStyles(),document.body.appendChild(this.panel),document.addEventListener("click",this.handleOutsideClick))}getPanelStyles(){var n;const e=(n=this.triggerBtn)==null?void 0:n.getBoundingClientRect(),t=300,s=400;let o=e?e.left-t-8:this.positionX-t-8,r=e?e.top:this.positionY;return o<8&&(o=e?e.right+8:this.positionX+60),o+t>window.innerWidth-8&&(o=window.innerWidth-t-8),r<8&&(r=e?e.bottom+8:this.positionY+60),r+s>window.innerHeight-8&&(r=window.innerHeight-s-8),`
      position: fixed;
      z-index: 9999;
      left: ${o}px;
      top: ${r}px;
      width: ${t}px;
      max-height: ${s}px;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 4px 24px rgba(0, 0, 0, 0.15);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    `}updatePanelContent(){var o,r;if(!this.panel)return;const e=this.corpusItems.length,t=this.corpusItems.filter(n=>n.selected).length;this.panel.innerHTML=`
      <div class="dbx-corpus-header">
        <span class="dbx-corpus-title">语料板</span>
        <span class="dbx-corpus-header-count">${e} 条</span>
        <button class="dbx-corpus-clear-btn" title="清空">清空</button>
      </div>
      <div class="dbx-corpus-list">
        ${this.corpusItems.length===0?'<div class="dbx-corpus-empty">暂无语料<br><small>选中文本后右键添加到语料板</small></div>':""}
        ${this.corpusItems.length>0?`
          <div class="dbx-corpus-select-all">
            <input type="checkbox" id="dbx-corpus-select-all" ${t===e&&e>0?"checked":""}>
            <label for="dbx-corpus-select-all">全选</label>
          </div>
        `:""}
        ${this.corpusItems.map(n=>`
          <div class="dbx-corpus-item ${n.selected?"selected":""}" data-id="${n.id}">
            <div class="dbx-corpus-item-checkbox">
              <input type="checkbox" ${n.selected?"checked":""}>
            </div>
            <div class="dbx-corpus-item-body">
              <div class="dbx-corpus-item-content">${this.escapeHtml(n.text)}</div>
            </div>
            <button class="dbx-corpus-item-remove" title="删除">×</button>
          </div>
        `).join("")}
      </div>
      <div class="dbx-corpus-footer">
        <button class="dbx-corpus-add-btn" ${t===0?"disabled":""}>添加到对话框${t>0?` (${t})`:""}</button>
      </div>
    `,this.updateTriggerCount(),(o=this.panel.querySelector(".dbx-corpus-clear-btn"))==null||o.addEventListener("click",()=>{this.clearCorpus()});const s=this.panel.querySelector("#dbx-corpus-select-all");s&&s.addEventListener("change",()=>{const n=s.checked;this.corpusItems.forEach(i=>{i.selected=n}),this.updatePanelContent()}),this.panel.querySelectorAll(".dbx-corpus-item").forEach(n=>{const i=n.querySelector('input[type="checkbox"]');i==null||i.addEventListener("change",()=>{const a=n.getAttribute("data-id"),l=this.corpusItems.find(d=>d.id===a);l&&(l.selected=i.checked,n.classList.toggle("selected",i.checked),this.updatePanelContent())})}),this.panel.querySelectorAll(".dbx-corpus-item-remove").forEach(n=>{n.addEventListener("click",i=>{var l;i.stopPropagation();const a=(l=i.target.closest(".dbx-corpus-item"))==null?void 0:l.getAttribute("data-id");a&&this.removeCorpusItem(a)})}),(r=this.panel.querySelector(".dbx-corpus-add-btn"))==null||r.addEventListener("click",()=>{this.addToInput()})}escapeHtml(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}updateTriggerCount(){var t;const e=(t=this.triggerBtn)==null?void 0:t.querySelector(".dbx-corpus-count");e&&(e.textContent=String(this.corpusItems.length))}hidePanel(){this.panel&&(this.panel.remove(),this.panel=null),document.removeEventListener("click",this.handleOutsideClick)}setupTextSelectionListener(){let e=null,t=null,s="",o=null,r="#fde047";console.log("[CorpusBoard] Setting up text selection listener");const n=(i,a)=>{if(console.log("[CorpusBoard] showSelectionButton called",a),!a||a.trim().length===0){e&&(e.style.display="none");return}s=a,console.log("[CorpusBoard] Saved selection text:",s);const l=i.getRangeAt(0);o=l.cloneRange();const d=l.getBoundingClientRect();console.log("[CorpusBoard] Selection rect:",d);const u=l.commonAncestorContainer,h=u.nodeType===Node.TEXT_NODE?u.parentElement:u;if(!h||h.closest(".dbx-popup-content")){console.log("[CorpusBoard] Selection in dbx-popup-content, not showing button");return}const m=B=>{var g;if(!B)return!1;const f=B.getAttribute("data-testid")||"";let A="";try{A=((g=B.className)==null?void 0:g.toString())||""}catch{A=""}return f.includes("message")||f.includes("message-list")||f.includes("message_content")||f.includes("message_text")||A.includes("message-list")||A.includes("message-block")||B.classList.contains("flow-markdown-body")||B.closest('[data-testid="message-list"]')?!0:m(B.parentElement)};if(!m(h)){console.log("[CorpusBoard] Selection not in chat message area, not showing button");return}if(!e){e=document.createElement("div"),e.className="dbx-corpus-selection-btn",e.innerHTML=`
  <span class="dbx-corpus-add-action">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <line x1="12" y1="5" x2="12" y2="19"></line>
      <line x1="5" y1="12" x2="19" y2="12"></line>
    </svg>
    <span>添加到语料板</span>
  </span>

  <span class="dbx-highlight-divider"></span>

  <button type="button" class="dbx-highlight-action" title="高亮标记">
    <svg class="dbx-highlight-icon" width="12" height="14"
  viewBox="0 0 122 147" aria-hidden="true">
  <rect
    x="22.3711"
    y="60.2461"
    width="85.2099"
    height="55.2471"
    transform="rotate(-44.9923 22.3711 60.2461)"
    class="dbx-highlight-icon-body"
  />
  <path
    d="M56.7333 103.832L17.6786 64.5547V90.6656L1.00195 110.413H27.1126L32.8175 103.832H56.7333Z"
    class="dbx-highlight-icon-tip"
  />
  <rect
    y="124.074"
    width="119.172"
    height="22.9062"
    class="dbx-highlight-icon-color"
  />
</svg>
  </button>

  <button type="button" class="dbx-highlight-menu-toggle" title="选择高亮颜色">
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <polyline points="6 9 12 15 18 9"></polyline>
    </svg>
  </button>

  <div class="dbx-highlight-palette" hidden>
  <button type="button" class="dbx-highlight-swatch dbx-highlight-remove" title="取消高亮">
    <svg viewBox="0 0 219 219" aria-hidden="true">
      <circle cx="109.481" cy="109.481" r="104.981" stroke="black" stroke-width="9" fill="none"/>
      <rect x="5.96094" y="185.586" width="254.852" height="23.1796" rx="11.5898"
        transform="rotate(-41.4035 5.96094 185.586)" fill="#F2696A"/>
    </svg>
  </button>
  <button type="button" class="dbx-highlight-swatch" data-color="#FDEB00" style="--dbx-swatch-color: #FDEB00" title="黄色"></button>
  <button type="button" class="dbx-highlight-swatch" data-color="#00E52B" style="--dbx-swatch-color: #00E52B" title="绿色"></button>
  <button type="button" class="dbx-highlight-swatch" data-color="#09DCE5" style="--dbx-swatch-color: #09DCE5" title="青色"></button>
  <button type="button" class="dbx-highlight-swatch" data-color="#F000C8" style="--dbx-swatch-color: #F000C8" title="粉色"></button>
  <button type="button" class="dbx-highlight-swatch" data-color="#FF1616" style="--dbx-swatch-color: #FF1616" title="红色"></button>
  <button type="button" class="dbx-highlight-swatch" data-color="#747A89" style="--dbx-swatch-color: #747A89" title="灰色"></button>
</div>
`,e.style.cssText=`
          position: fixed;
          z-index: 10000;
          display: flex;
          align-items: center;
          gap: 4px;
          padding: 6px 10px;
          background: #4f46e5;
          color: #fff;
          font-size: 12px;
          font-weight: 500;
          border-radius: 6px;
          box-shadow: 0 2px 8px rgba(79, 70, 229, 0.4);
          cursor: pointer;
          white-space: nowrap;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        `;const B=e.querySelector(".dbx-corpus-add-action");B==null||B.addEventListener("click",y=>{y.stopPropagation(),s&&(this.addToCorpus(s),this.flashTriggerButton()),e.style.display="none",s="",o=null});const f=e.querySelector(".dbx-highlight-action"),A=async y=>{var L;if(!o||o.collapsed)return;const k=o.cloneRange(),M=this.findHighlightMessageRoot(k.startContainer),x=this.createTextHighlightAnchor(k,y);if(!M||!x||!M.contains(k.endContainer)){console.warn("[CorpusBoard] Could not locate the selected message");return}try{await this.removeSelectedHighlightPortions(k.cloneRange());const T=this.createRangeFromTextOffsets(M,x.startOffset,x.endOffset);if(!T||T.toString()!==x.text){console.warn("[CorpusBoard] Could not rebuild the selected range");return}const D=this.wrapRangeWithHighlight(T,y);if(D.length===0)return;const F=await w.addTextHighlight(x);D.forEach($=>{$.dataset.dbxHighlightId=F.id,$.dataset.dbxConversationId=F.conversationId}),await w.save(),(L=window.getSelection())==null||L.removeAllRanges(),e.style.display="none",s="",o=null}catch(T){console.error("[CorpusBoard] Failed to highlight text:",T)}};f==null||f.addEventListener("click",y=>{y.stopPropagation(),A(r)});const g=e.querySelector(".dbx-highlight-menu-toggle"),c=e.querySelector(".dbx-highlight-palette"),b=()=>{if(!c||c.hidden||!e)return;const y=8,k=64,M=5,x=e.getBoundingClientRect(),L=c.getBoundingClientRect();let T=x.right-k,D=x.bottom-M;T+L.width>window.innerWidth-y&&(T=x.left-L.width+k),D+L.height>window.innerHeight-y&&(D=x.top-L.height+M);const F=Math.max(y,window.innerWidth-L.width-y),$=Math.max(y,window.innerHeight-L.height-y);c.style.left=`${Math.min(Math.max(y,T),F)}px`,c.style.top=`${Math.min(Math.max(y,D),$)}px`};this.highlightPaletteResizeHandler=b,window.addEventListener("resize",b),g==null||g.addEventListener("click",y=>{y.stopPropagation(),c&&(c.hidden=!c.hidden,g.classList.toggle("is-open",!c.hidden),c.hidden||window.requestAnimationFrame(b))}),c==null||c.querySelectorAll(".dbx-highlight-swatch[data-color]").forEach(y=>{y.addEventListener("click",k=>{k.stopPropagation();const M=y.dataset.color;M&&(r=M,f==null||f.style.setProperty("--dbx-highlight-color",r),A(r))})});const E=e.querySelector(".dbx-highlight-remove");E==null||E.addEventListener("click",async y=>{var k;y.stopPropagation(),o&&(await this.removeSelectedHighlightPortions(o.cloneRange()),(k=window.getSelection())==null||k.removeAllRanges(),e.style.display="none",s="",o=null)}),document.body.appendChild(e)}const C=e.getBoundingClientRect(),S=d.left+d.width/2-C.width/2,I=d.bottom+8,H=e.querySelector(".dbx-highlight-palette"),q=e.querySelector(".dbx-highlight-menu-toggle");H&&(H.hidden=!0),q==null||q.classList.remove("is-open"),e.style.left=`${Math.max(8,S)}px`,e.style.top=`${Math.min(I,window.innerHeight-40)}px`,e.style.display="flex"};document.addEventListener("mouseup",i=>{t&&(clearTimeout(t),t=null);const a=i.target;if(a.closest(".dbx-corpus-panel")||a.closest(".dbx-corpus-trigger")||a.closest(".dbx-corpus-selection-btn"))return;const l=window.getSelection(),d=(l==null?void 0:l.toString().trim())||"";if(console.log("[CorpusBoard] mouseup, selection text:",d),d.length>0){const h=l.getRangeAt(0).commonAncestorContainer,m=h.nodeType===Node.TEXT_NODE?h.parentElement:h;if(m){if(console.log("[CorpusBoard] Selection container:",m.tagName,m.className),m.closest(".dbx-popup-content")){console.log("[CorpusBoard] Selection in dbx-popup-content"),e&&(e.style.display="none");return}const C=S=>{var q;if(!S)return!1;const I=S.getAttribute("data-testid")||"";let H="";try{H=((q=S.className)==null?void 0:q.toString())||""}catch{H=""}return I.includes("message")||I.includes("message-list")||I.includes("message_content")||I.includes("message_text")||H.includes("message-list")||H.includes("message-block")||S.classList.contains("flow-markdown-body")||S.closest('[data-testid="message-list"]')?!0:C(S.parentElement)};if(!C(m)){console.log("[CorpusBoard] Selection not in chat message area"),e&&(e.style.display="none");return}}n(l,d)}else t=window.setTimeout(()=>{e&&(e.style.display="none")},200)}),document.addEventListener("mousedown",i=>{const a=i.target,l=h=>{var S;if(!h)return!1;const m=h.getAttribute("data-testid")||"";let C="";try{C=((S=h.className)==null?void 0:S.toString())||""}catch{C=""}return m.includes("message")||m.includes("message-list")||m.includes("message_content")||m.includes("message_text")||C.includes("message-list")||C.includes("message-block")||h.classList.contains("flow-markdown-body")||h.closest('[data-testid="message-list"]')?!0:l(h.parentElement)},d=a.closest(".dbx-corpus-selection-btn")||a.closest(".dbx-corpus-panel")||a.closest(".dbx-corpus-trigger"),u=a.closest(".dbx-popup-content");!d&&!l(a)&&!u&&e&&(e.style.display="none")})}setupHighlightPersistence(){this.lastHighlightUrl=window.location.href,this.scheduleHighlightRestore(300),this.highlightObserver=new MutationObserver(e=>{if(window.location.href!==this.lastHighlightUrl){this.handleHighlightConversationChange();return}e.some(s=>s.addedNodes.length>0||s.removedNodes.length>0)&&this.scheduleHighlightRestore(350)}),this.highlightObserver.observe(document.body,{childList:!0,subtree:!0}),this.highlightUrlTimer=window.setInterval(()=>{window.location.href!==this.lastHighlightUrl&&this.handleHighlightConversationChange()},1e3)}async handleHighlightConversationChange(){this.lastHighlightUrl=window.location.href,this.clearRenderedHighlights(),await this.loadCorpusItems(),this.updateTriggerCount(),this.scheduleHighlightRestore(500)}scheduleHighlightRestore(e){this.highlightRestoreTimer&&clearTimeout(this.highlightRestoreTimer),this.highlightRestoreTimer=window.setTimeout(()=>{this.highlightRestoreTimer=null,this.restoreTextHighlights()},e)}async restoreTextHighlights(){if(this.isRestoringHighlights)return;const e=this.getConversationId();if(e!=="unknown"){this.isRestoringHighlights=!0;try{const t=await w.getTextHighlights(e);for(const s of t){if(Array.from(document.querySelectorAll(".dbx-text-highlight")).some(l=>l.dataset.dbxHighlightId===s.id))continue;const r=this.findRootForSavedHighlight(s);if(!r)continue;const n=this.findSavedHighlightOffset(r,s);if(n===null)continue;const i=this.createRangeFromTextOffsets(r,n,n+s.text.length);if(!i||i.toString()!==s.text)continue;const a=this.wrapRangeWithHighlight(i,s.color);a.length!==0&&a.forEach(l=>{l.dataset.dbxHighlightId=s.id,l.dataset.dbxConversationId=s.conversationId})}}catch(t){console.error("[CorpusBoard] Failed to restore text highlights:",t)}finally{this.isRestoringHighlights=!1}}}createTextHighlightAnchor(e,t){const s=this.findHighlightMessageRoot(e.startContainer);if(!s||!s.contains(e.endContainer))return null;const o=e.toString();if(!o)return null;try{const r=e.cloneRange();r.selectNodeContents(s),r.setEnd(e.startContainer,e.startOffset);const n=r.toString().length,i=n+o.length,a=s.textContent??"",l=this.getHighlightMessageRoots(),d=Math.max(0,l.indexOf(s));return{conversationId:this.getConversationId(),messageId:this.getHighlightMessageId(s),messageIndex:d,text:o,startOffset:n,endOffset:i,prefix:a.slice(Math.max(0,n-48),n),suffix:a.slice(i,i+48),color:t}}catch(r){return console.error("[CorpusBoard] Failed to capture highlight position:",r),null}}findHighlightMessageRoot(e){const t=e.nodeType===Node.ELEMENT_NODE?e:e.parentElement;if(!t)return null;const s=t.closest('.flow-markdown-body, [data-testid="message_content"], [data-testid="message_text"]');if(s)return s;const o=t.closest('[data-message-id], [data-testid="union_message"], [data-testid="message-block-container"], [class*="message-block"]');return o?o.querySelector('.flow-markdown-body, [data-testid="message_content"], [data-testid="message_text"]')??o:null}getHighlightMessageRoots(){const e=[],t=s=>{s.closest(".dbx-corpus-selection-btn, .dbx-corpus-panel")||e.includes(s)||e.push(s)};return document.querySelectorAll('[data-message-id], [data-testid="union_message"], [data-testid="message-block-container"]').forEach(s=>{const o=s.querySelector('.flow-markdown-body, [data-testid="message_content"], [data-testid="message_text"]')??s;t(o)}),document.querySelectorAll('.flow-markdown-body, [data-testid="message_content"], [data-testid="message_text"]').forEach(t),e}getHighlightMessageId(e){const t=e.closest('[data-testid="union_message"], [data-testid="message-block-container"], [class*="message-block"]'),s=e.closest("[data-message-id]")??e.querySelector("[data-message-id]")??(t==null?void 0:t.querySelector("[data-message-id]"));return(s==null?void 0:s.getAttribute("data-message-id"))??void 0}findRootForSavedHighlight(e){const t=this.getHighlightMessageRoots();if(e.messageId){const o=t.find(r=>this.getHighlightMessageId(r)===e.messageId);if(o)return o}const s=t[e.messageIndex];return s&&this.findSavedHighlightOffset(s,e)!==null?s:t.find(o=>this.findSavedHighlightOffset(o,e)!==null)??null}findSavedHighlightOffset(e,t){const s=e.textContent??"";if(!t.text||!s.includes(t.text))return null;if(s.slice(t.startOffset,t.endOffset)===t.text)return t.startOffset;const o=`${t.prefix}${t.text}${t.suffix}`,r=o?s.indexOf(o):-1;if(r>=0)return r+t.prefix.length;let n=null,i=Number.NEGATIVE_INFINITY,a=0;for(;a<=s.length;){const l=s.indexOf(t.text,a);if(l<0)break;const d=!t.prefix||s.slice(Math.max(0,l-t.prefix.length),l).endsWith(t.prefix),u=!t.suffix||s.slice(l+t.text.length,l+t.text.length+t.suffix.length).startsWith(t.suffix),h=Math.abs(l-t.startOffset),m=(d?1e3:0)+(u?1e3:0)-h;m>i&&(i=m,n=l),a=l+Math.max(1,t.text.length)}return n}createRangeFromTextOffsets(e,t,s){const o=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);let r=0,n=null,i=null,a=0,l=0;for(;o.nextNode();){const u=o.currentNode,h=r+u.data.length;if(!n&&t>=r&&t<=h&&(n=u,a=t-r),!i&&s>=r&&s<=h&&(i=u,l=s-r),r=h,n&&i)break}if(!n||!i)return null;const d=document.createRange();return d.setStart(n,a),d.setEnd(i,l),d}getTextPartsInRange(e){const t=e.commonAncestorContainer.nodeType===Node.TEXT_NODE?e.commonAncestorContainer.parentElement:e.commonAncestorContainer;if(!t)return[];const s=document.createTreeWalker(t,NodeFilter.SHOW_TEXT),o=[];for(;s.nextNode();){const r=s.currentNode;try{if(!e.intersectsNode(r))continue}catch{continue}const n=r===e.startContainer?e.startOffset:0,i=r===e.endContainer?e.endOffset:r.data.length;i<=n||r.data.slice(n,i).trim()&&o.push({node:r,startOffset:n,endOffset:i})}return o}wrapRangeWithHighlight(e,t){try{const s=this.getTextPartsInRange(e),o=[];return[...s].reverse().forEach(({node:r,startOffset:n,endOffset:i})=>{const a=document.createElement("mark");a.className="dbx-text-highlight",a.style.backgroundColor=t;const l=document.createRange();l.setStart(r,n),l.setEnd(r,i);const d=l.extractContents();a.appendChild(d),l.insertNode(a),o.unshift(a)}),o}catch(s){return console.error("[CorpusBoard] Failed to wrap highlighted text:",s),[]}}unwrapHighlight(e){const t=e.parentNode;if(t){for(;e.firstChild;)t.insertBefore(e.firstChild,e);e.remove(),t.normalize()}}async removeSelectedHighlightPortions(e){const t=this.createTextHighlightAnchor(e,""),s=this.findHighlightMessageRoot(e.startContainer);if(!t||!s||!s.contains(e.endContainer))return;const o=Array.from(s.querySelectorAll(".dbx-text-highlight")),r=o.filter(n=>{try{return e.intersectsNode(n)}catch{return!1}});if(r.length!==0)try{const n=await w.getTextHighlights(t.conversationId),i=new Map(n.map(u=>[u.id,u])),a=[],l=new Set,d=new Set;r.forEach(u=>{const h=u.dataset.dbxHighlightId,m=h?i.get(h):void 0;if(!h||!m){d.add(u);return}if(l.has(h))return;const C=Math.max(m.startOffset,t.startOffset),S=Math.min(m.endOffset,t.endOffset);C>=S||(m.startOffset<C&&a.push({startOffset:m.startOffset,endOffset:C,color:m.color}),S<m.endOffset&&a.push({startOffset:S,endOffset:m.endOffset,color:m.color}),l.add(h))}),o.forEach(u=>{const h=u.dataset.dbxHighlightId;h&&l.has(h)&&d.add(u)}),d.forEach(u=>this.unwrapHighlight(u)),await Promise.all(Array.from(l).map(u=>w.removeTextHighlight(u))),a.sort((u,h)=>u.startOffset-h.startOffset);for(const u of a){if(u.endOffset<=u.startOffset)continue;const h=this.createRangeFromTextOffsets(s,u.startOffset,u.endOffset);if(!h||!h.toString())continue;const m=this.createTextHighlightAnchor(h,u.color);if(!m)continue;const C=this.wrapRangeWithHighlight(h,u.color);if(C.length===0)continue;const S=await w.addTextHighlight(m);C.forEach(I=>{I.dataset.dbxHighlightId=S.id,I.dataset.dbxConversationId=S.conversationId})}await w.save()}catch(n){console.error("[CorpusBoard] Failed to partially remove highlight:",n)}}clearRenderedHighlights(){document.querySelectorAll(".dbx-text-highlight").forEach(e=>this.unwrapHighlight(e))}flashTriggerButton(){this.triggerBtn&&(this.triggerBtn.style.transform="scale(1.2)",this.triggerBtn.style.boxShadow="0 0 0 4px rgba(79, 70, 229, 0.3)",setTimeout(()=>{this.triggerBtn&&(this.triggerBtn.style.transform="scale(1)",this.triggerBtn.style.boxShadow="")},300))}async addToCorpus(e){console.log("[CorpusBoard] addToCorpus called with text:",e);const t=this.getConversationId(),s=this.getConversationTitle();console.log("[CorpusBoard] conversationId:",t,"conversationTitle:",s);try{console.log("[CorpusBoard] Calling storageService.addToCorpusBoard...");const o=await w.addToCorpusBoard(e,t,s);console.log("[CorpusBoard] Item added:",o),this.corpusItems.push(o),this.updateTriggerCount(),this.isExpanded&&this.panel&&this.updatePanelContent()}catch(o){console.error("[CorpusBoard] Failed to add corpus:",o)}}async removeCorpusItem(e){try{await w.removeFromCorpusBoard(e),this.corpusItems=this.corpusItems.filter(t=>t.id!==e),this.updateTriggerCount(),this.isExpanded&&this.panel&&this.updatePanelContent()}catch(t){console.error("[CorpusBoard] Failed to remove corpus:",t)}}async clearCorpus(){try{await w.clearCorpusBoard(),this.corpusItems=[],this.updateTriggerCount(),this.isExpanded&&this.panel&&this.updatePanelContent()}catch(e){console.error("[CorpusBoard] Failed to clear corpus:",e)}}async addToInput(){const e=this.corpusItems.filter(o=>o.selected);if(e.length===0)return;const t=e.map(o=>`[${o.text}]`).join(`
`),s=this.findInputArea();if(s){const o=s.querySelector("textarea"),r=s.querySelector('div[contenteditable="true"]');if(o){const n=o.value;o.value=n+(n?`
`:"")+t,o.dispatchEvent(new Event("input",{bubbles:!0}))}else if(r){const n=r.textContent||"";r.textContent=n+(n?`
`:"")+t,r.dispatchEvent(new InputEvent("input",{bubbles:!0}))}}this.corpusItems.forEach(o=>{o.selected=!1}),this.isExpanded=!1,this.hidePanel()}findInputArea(){const e=[".relative.flex.flex-col-reverse.justify-between.items-end",".flex-col-reverse.items-end.p-10",'[class*="flex-col-reverse"][class*="items-end"]','[class*="p-10"][class*="flex-col-reverse"]','[class*="justify-between"][class*="flex-col-reverse"]','[data-testid="send_textarea"]','textarea[placeholder*="发送"]','div[contenteditable="true"]','[class*="input"]','[class*="composer"]','[class*="chat-input"]'];for(const t of e){const s=document.querySelector(t);if(s)return console.log("[CorpusBoard] findInputArea found:",t),s}return console.log("[CorpusBoard] findInputArea: no element found"),null}getConversationId(){const e=window.location.pathname.match(/\/chat\/([^/?#]+)/);return e?e[1]:"unknown"}getConversationTitle(){var t;const e=document.querySelector('[class*="title"], [class*="header"] h1, h1');return((t=e==null?void 0:e.textContent)==null?void 0:t.trim())||"未知对话"}destroy(){this.highlightPaletteResizeHandler&&(window.removeEventListener("resize",this.highlightPaletteResizeHandler),this.highlightPaletteResizeHandler=null),this.highlightObserver&&(this.highlightObserver.disconnect(),this.highlightObserver=null),this.highlightRestoreTimer&&(clearTimeout(this.highlightRestoreTimer),this.highlightRestoreTimer=null),this.highlightUrlTimer&&(clearInterval(this.highlightUrlTimer),this.highlightUrlTimer=null),this.triggerBtn&&(this.triggerBtn.remove(),this.triggerBtn=null),this.panel&&(this.panel.remove(),this.panel=null),this.initialized=!1}}const X=new fe;class xe{constructor(){v(this,"initialized",!1);v(this,"exportButton",null);v(this,"dropdownMenu",null)}init(){if(this.initialized){this.ensureButtonVisible();return}console.log("[ExportManager] Initializing..."),this.waitForTopbar(),this.ensureButtonVisible(),this.initialized=!0}ensureButtonVisible(){setTimeout(()=>{const e=document.getElementById("dbx-export-btn");if(!e){this.waitForTopbar();return}const t=document.querySelector('[class*="header-height"]')||document.querySelector("header")||document.querySelector('[class*="border-b"]');t&&!t.contains(e)&&(e.remove(),this.exportButton=null,this.addExportButton(t))},1e3)}waitForTopbar(){const e=()=>{const t=document.querySelector('[class*="header-height"]')||document.querySelector("header")||document.querySelector('[class*="border-b"]');t?(console.log("[ExportManager] Topbar found, adding export button"),this.addExportButton(t)):setTimeout(e,500)};e()}addExportButton(e){if(document.getElementById("dbx-export-btn"))return;this.exportButton=document.createElement("button"),this.exportButton.id="dbx-export-btn",this.exportButton.innerHTML=`
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
        <polyline points="7 10 12 15 17 10"></polyline>
        <line x1="12" y1="15" x2="12" y2="3"></line>
      </svg>
    `,this.exportButton.style.cssText=`
      display: flex;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
      padding: 4px;
      color: var(--dbx-text-primary, #1f2937);
      background: transparent;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      transition: background-color 0.15s ease;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      flex-shrink: 0;
    `,this.exportButton.setAttribute("data-dbx-name","button"),this.exportButton.setAttribute("data-disabled","false"),this.exportButton.addEventListener("mouseenter",()=>{this.exportButton.style.backgroundColor="var(--dbx-fill-trans-20-hover, rgba(0, 0, 0, 0.05))"}),this.exportButton.addEventListener("mouseleave",()=>{this.exportButton.style.backgroundColor="transparent"}),this.exportButton.addEventListener("click",r=>{r.stopPropagation(),this.toggleDropdown()});const s=e.querySelector('[class*="flex-row"]'),o=e.querySelector('div[class*="justify-end"]');if(o)o.insertBefore(this.exportButton,o.firstChild);else if(s&&s.parentElement===e){const r=document.createElement("div");r.style.cssText="display: flex; align-items: center; gap: 8px; flex-shrink: 0;",e.appendChild(r),r.appendChild(this.exportButton)}else e.appendChild(this.exportButton);document.addEventListener("click",r=>{var n;this.dropdownMenu&&!this.dropdownMenu.contains(r.target)&&!((n=this.exportButton)!=null&&n.contains(r.target))&&this.hideDropdown()})}toggleDropdown(){this.dropdownMenu&&this.dropdownMenu.style.display==="flex"?this.hideDropdown():this.showDropdown()}showDropdown(){if(!this.dropdownMenu){this.dropdownMenu=document.createElement("div"),this.dropdownMenu.id="dbx-export-dropdown",this.dropdownMenu.style.cssText=`
        position: absolute;
        top: 100%;
        right: 0;
        margin-top: 4px;
        min-width: 140px;
        background: var(--dbx-folder-bg-base, #fff);
        border: 1px solid var(--dbx-line-7, #e5e7eb);
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        display: flex;
        flex-direction: column;
        z-index: 10000;
        overflow: hidden;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      `;const t=this.createDropdownItem("导出为 PDF",()=>this.exportToPdf()),s=this.createDropdownItem("导出为 TXT",()=>this.exportToTxt()),o=this.createDropdownItem("导出为 Markdown",()=>this.exportToMarkdown());this.dropdownMenu.appendChild(t),this.dropdownMenu.appendChild(s),this.dropdownMenu.appendChild(o)}const e=this.exportButton.getBoundingClientRect();this.dropdownMenu.style.position="fixed",this.dropdownMenu.style.left=`${e.left}px`,this.dropdownMenu.style.top=`${e.bottom}px`,this.dropdownMenu.style.display="flex",document.body.appendChild(this.dropdownMenu)}hideDropdown(){this.dropdownMenu&&(this.dropdownMenu.style.display="none")}createDropdownItem(e,t){const s=document.createElement("button");return s.textContent=e,s.style.cssText=`
      display: block;
      width: 100%;
      padding: 10px 16px;
      font-size: 14px;
      color: var(--dbx-text-primary, #1f2937);
      background: transparent;
      border: none;
      text-align: left;
      cursor: pointer;
      transition: background-color 0.15s ease;
    `,s.addEventListener("mouseenter",()=>{s.style.backgroundColor="var(--dbx-fill-trans-20-hover, rgba(0, 0, 0, 0.05))"}),s.addEventListener("mouseleave",()=>{s.style.backgroundColor="transparent"}),s.addEventListener("click",o=>{o.stopPropagation(),this.hideDropdown(),t()}),s}async getConversationMessages(){var o;const e=[],t=((o=document.querySelector("[data-message-id]"))==null?void 0:o.closest('main, [class*="page-main"], [class*="chat-container"]'))||document.querySelector("main");if(!t)return console.log("[ExportManager] Chat container not found"),e;const s=t.querySelectorAll("[data-message-id]");return console.log("[ExportManager] Found message wrappers:",s.length),s.forEach(r=>{var g;const n=r.querySelectorAll('[data-render-engine="node"], [data-render-engine="block"]'),i=Array.from(n).map(c=>c.getAttribute("data-plugin-identifier")||""),a=i.map(c=>{const b=c.match(/block_type:(\d+)/);return b?b[1]:""}),l=a.some(c=>c==="10040"),d=a.some(c=>c==="10000"),u=i.some(c=>c.includes("Symbol(")),h=r.querySelector('[class*="bubble"], [class*="send-msg"], [class*="message-bubble"]'),m=r.querySelector('.flow-markdown-body, [class*="markdown-body"]'),C=r.querySelector('[class*="image-box"], [class*="image-grid"]');if(!d&&!l&&!u&&!h&&!m&&!C)return;const I=(((g=r.innerHTML)==null?void 0:g.toLowerCase())||"").includes("send_message")||r.querySelector('[class*="send-msg"], [class*="send_message"], [class*="user-bubble"], [class*="bubble-bg"]')?"user":"assistant",H=r.cloneNode(!0);["svg:not([data-dbx-name])","button:not([data-dbx-name])",'[class*="avatar"]','[class*="time"]','[class*="tool"]','[class*="collapse"]','[class*="think-block"]','[class*="thinking"]','[class*="collapse-button"]','[class*="collapse-wrapper"]','[class*="scroll-content"]','[class*="scroll-view"]','[class*="action-bar"]','[class*="message-action"]','[class*="select-none"]','[class*="opacity-0"]',"script","style",".children-wrapper",".scrollable-Se7zNt"].forEach(c=>{H.querySelectorAll(c).forEach(b=>b.remove())});let B="";const f=H.querySelectorAll("img").length>0;B=H.innerHTML.trim();const A=typeof B=="string"?B.replace(/\s+/g," ").trim():B;A&&A.length>0&&e.push({id:r.getAttribute("data-message-id")||`msg_${e.length}`,role:I,content:B,hasImages:f})}),console.log("[ExportManager] Found messages:",e.length,"user:",e.filter(r=>r.role==="user").length,"assistant:",e.filter(r=>r.role==="assistant").length,"with images:",e.filter(r=>r.hasImages).length),e}getConversationTitle(){var r,n,i;const e=document.querySelector('[class*="title"]:not([class*="icon"]):not([class*="button"]):not([class*="tooltip"])');if(e&&((r=e.textContent)!=null&&r.trim()))return e.textContent.trim().substring(0,50);const t=document.querySelector("h1");if(t&&((n=t.textContent)!=null&&n.trim()))return t.textContent.trim().substring(0,50);const s=document.querySelector('[data-testid*="title"], [data-title]');if(s&&((i=s.textContent)!=null&&i.trim()))return s.textContent.trim().substring(0,50);const o=window.location.pathname.match(/\/chat\/([^/?#]+)/);return o?`对话_${o[1].substring(0,8)}`:"对话导出"}htmlToMarkdown(e){const t=document.createElement("div");t.innerHTML=e;const s=r=>{if(r.nodeType===Node.TEXT_NODE)return r.textContent||"";if(r.nodeType!==Node.ELEMENT_NODE)return"";const n=r;switch(n.tagName.toLowerCase()){case"br":return`
`;case"p":return Array.from(n.childNodes).map(s).join(`

`)+`
`;case"div":return Array.from(n.childNodes).map(s).join(`
`)+`
`;case"span":return Array.from(n.childNodes).map(s).join("");case"strong":case"b":return`**${Array.from(n.childNodes).map(s).join("")}**`;case"em":case"i":return`*${Array.from(n.childNodes).map(s).join("")}*`;case"code":const a=Array.from(n.childNodes).map(s).join("");return n.closest("pre")?`
\`\`\`
${a}
\`\`\`
`:`\`${a}\``;case"pre":const l=n.querySelector("code"),d=l?l.textContent||"":n.textContent||"",u=l==null?void 0:l.className.match(/language-(\w+)/);return`
\`\`\`${u?u[1]:""}
${d.trim()}
\`\`\`
`;case"a":const m=n.getAttribute("href")||"";return`[${n.textContent||""}](${m})`;case"img":const C=n.getAttribute("src")||n.getAttribute("data-src")||"";if(C.startsWith("data:")||C.includes("base64"))return"";const S=n.getAttribute("alt")||"image";return C?`![${S}](${C})`:"";case"ul":return Array.from(n.childNodes).map(A=>`  - ${s(A)}`).join(`
`)+`
`;case"ol":let I=1;return Array.from(n.childNodes).map(A=>`  ${I++}. ${s(A).replace(/^\s*-\s*/,"")}`).join(`
`)+`
`;case"li":return Array.from(n.childNodes).map(s).join("");case"h1":return`# ${n.textContent||""}
`;case"h2":return`## ${n.textContent||""}
`;case"h3":return`### ${n.textContent||""}
`;case"h4":return`#### ${n.textContent||""}
`;case"blockquote":return`> ${n.textContent||""}
`;case"hr":return`---
`;case"table":const H=[];if(n.querySelectorAll("tr").forEach(A=>{const g=[];A.querySelectorAll("th, td").forEach(c=>{g.push(s(c).trim())}),g.length>0&&H.push(g)}),H.length===0)return"";const q=H[0].join(" | "),B=H[0].map(()=>"---").join(" | "),f=H.slice(1).map(A=>A.join(" | ")).join(`
`);return`
| ${q} |
| ${B} |
${f?"| "+f.replace(/\n/g,`
| `)+"|":""}
`;default:return Array.from(n.childNodes).map(s).join("")}};let o=s(t);return o=o.replace(/\n{3,}/g,`

`).replace(/ {2,}/g," ").trim(),o}async exportToPdf(){console.log("[ExportManager] Exporting to PDF...");const e=await this.getConversationMessages(),t=this.getConversationTitle(),s=e.filter(a=>a.role==="user"),o=e.filter(a=>a.role==="assistant"),r=a=>{const l=document.createElement("div");return l.innerHTML=a,l.querySelectorAll("pre code, pre").forEach(f=>{const A=f.tagName==="PRE"?f:f.parentElement;A&&(A.style.cssText="background: #f6f8fa; border-radius: 6px; padding: 12px; margin: 8px 0; overflow-x: auto; font-family: monospace; font-size: 11px; line-height: 1.4; border: 1px solid #e1e4e8;")}),l.querySelectorAll('[class*="image-wrapper"], [class*="image-box-grid"], [class*="container-MzuYIN"], [class*="container-dLabXv"], [class*="image-box-grid-item"]').forEach(f=>{f.querySelectorAll("img").forEach(g=>{const c=f.parentElement;c&&c.insertBefore(g.cloneNode(!0),f)}),f.remove()}),l.querySelectorAll("picture").forEach(f=>{const A=f.querySelectorAll("source"),g=f.querySelector("img");g&&A.forEach(c=>{const b=c.getAttribute("srcset");b&&!b.includes("data:")&&g.setAttribute("src",b.split(" ")[0])})}),l.querySelectorAll("img").forEach(f=>{const A=f.getAttribute("src")||f.getAttribute("data-src")||"";if(!A)return;const g=A.toLowerCase();if(g.includes("data:image/svg")||g.includes("width=2048")||g.includes('width="2048')){f.remove();return}(A.startsWith("//")||A.startsWith("/"))&&f.setAttribute("src","https:"+A),f.style.cssText="max-width: 200px; height: auto; border-radius: 4px; margin: 4px; display: inline-block; vertical-align: top;",f.onerror=function(){this.style.display="none"}}),l.querySelectorAll("h1").forEach(f=>{f.style.cssText="font-size: 14px; font-weight: 600; margin: 12px 0 8px 0; color: #1f2937;"}),l.querySelectorAll("h2").forEach(f=>{f.style.cssText="font-size: 13px; font-weight: 600; margin: 10px 0 6px 0; color: #374151;"}),l.querySelectorAll("ul, ol").forEach(f=>{f.style.cssText="margin: 8px 0; padding-left: 20px;"}),l.querySelectorAll("li").forEach(f=>{f.style.cssText="margin: 4px 0;"}),l.querySelectorAll("p").forEach(f=>{f.style.cssText="margin: 8px 0;"}),l.querySelectorAll("strong").forEach(f=>{f.style.cssText="font-weight: 600;"}),l.innerHTML},n=`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>${t}</title>
        <style>
          @page {
            size: A4;
            margin: 15mm;
          }
          * {
            box-sizing: border-box;
          }
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #1f2937;
            background: #fff;
            padding: 15px;
            max-width: 100%;
          }
          h1 {
            font-size: 16px;
            font-weight: 600;
            margin: 0 0 12px 0;
            padding-bottom: 8px;
            border-bottom: 1px solid #e5e7eb;
          }
          .meta {
            font-size: 11px;
            color: #6b7280;
            margin-bottom: 16px;
          }
          .conversation {
            display: flex;
            flex-direction: column;
          }
          .message {
            padding: 10px 12px;
            border-radius: 6px;
            break-inside: avoid;
            margin-bottom: 8px;
          }
          .message-user {
            background: #f3f4f6;
            margin-right: 40px;
          }
          .message-assistant {
            background: #f9fafb;
            margin-left: 40px;
          }
          .message:last-child {
            margin-bottom: 0;
          }
          .role {
            font-size: 10px;
            font-weight: 600;
            margin-bottom: 2px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }
          .message-user .role {
            color: #4b5563;
          }
          .message-assistant .role {
            color: #6b7280;
          }
          .content {
            white-space: pre-wrap;
            word-wrap: break-word;
            margin: 0;
            padding: 0;
          }
          .content p {
            margin: 0 0 4px 0;
          }
          .content p:last-child {
            margin-bottom: 0;
          }
          @media print {
            body {
              padding: 0;
            }
            .message {
              page-break-inside: avoid;
            }
          }
        </style>
      </head>
      <body>
        <h1>${t}</h1>
        <div class="meta">共 ${e.length} 条消息（用户: ${s.length}, AI: ${o.length}）</div>
        <div class="conversation">
          ${e.map(a=>`
            <div class="message message-${a.role}">
              <div class="role">${a.role==="user"?"用户":"AI"}</div>
              <div class="content">${r(a.content)}</div>
            </div>
          `).join("")}
        </div>
      </body>
      </html>
    `,i=window.open("","_blank");i&&(i.document.write(n),i.document.close(),setTimeout(()=>{i.print()},250))}async exportToTxt(){console.log("[ExportManager] Exporting to TXT...");const e=await this.getConversationMessages(),t=this.getConversationTitle(),s=new Date().toLocaleDateString("zh-CN"),o=e.filter(a=>a.role==="user").length,r=e.filter(a=>a.role==="assistant").length,n=a=>{const l=/<img[^>]+src=["']([^"']+)["'][^>]*>/gi,d=[];let u;for(;(u=l.exec(a))!==null;)d.push(u[1]);return d},i=[t,"─".repeat(40),`导出日期: ${s}`,`共 ${e.length} 条消息（用户: ${o}, AI: ${r}）`,"",...e.map(a=>{const l=a.role==="user"?"【用户】":"【AI】",d=this.htmlToMarkdown(a.content);if(a.hasImages){const u=n(a.content);if(u.length>0)return`${l}
${d}

[图片: ${u.join(", ")}]
`}return`${l}
${d}
`})].join(`
`);this.downloadFile(i,`${t}.txt`,"text/plain;charset=utf-8")}async exportToMarkdown(){console.log("[ExportManager] Exporting to Markdown...");const e=await this.getConversationMessages(),t=this.getConversationTitle(),s=new Date().toLocaleDateString("zh-CN"),o=e.filter(a=>a.role==="user").length,r=e.filter(a=>a.role==="assistant").length,n=a=>{const l=/<img[^>]+src=["']([^"']+)["'][^>]*>/gi,d=[];let u;for(;(u=l.exec(a))!==null;)d.push(u[1]);return d},i=[`# ${t}`,"",`> 导出日期: ${s}`,`> 共 ${e.length} 条消息（用户: ${o}, AI: ${r}）`,"","---","",...e.map(a=>{const l=a.role==="user"?"**用户**":"**AI**",d=this.htmlToMarkdown(a.content);let u=`### ${l}

${d}`;return a.hasImages&&n(a.content).forEach(m=>{u+=`

![图片](${m})`}),u})].join(`
`);this.downloadFile(i,`${t}.md`,"text/markdown;charset=utf-8")}downloadFile(e,t,s){const o=new Blob([e],{type:s}),r=URL.createObjectURL(o),n=document.createElement("a");n.href=r,n.download=t,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(r)}}const Y=new xe;class be{constructor(){v(this,"initialized",!1);v(this,"processedElements",new WeakSet)}init(){this.initialized||(this.initialized=!0,this.setupObserver(),setTimeout(()=>this.processExistingFormulas(),500),setTimeout(()=>this.processExistingFormulas(),1500),setTimeout(()=>this.processExistingFormulas(),3e3))}setupObserver(){new MutationObserver(t=>{var o,r;let s=!1;for(const n of t){if(n.type==="childList"&&n.addedNodes.length>0){for(const i of n.addedNodes)if(i instanceof Element&&(i.querySelector(".math-inline, .math-block, .custom-code-block-container--latex, [copy-text]")||(o=i.classList)!=null&&o.contains("math-inline")||(r=i.classList)!=null&&r.contains("math-block"))){s=!0;break}}if(n.type==="attributes"&&(n.attributeName==="copy-text"||n.attributeName==="data-custom-copy-text")){s=!0;break}if(s)break}s&&setTimeout(()=>this.processExistingFormulas(),200)}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["copy-text","data-custom-copy-text"]})}processExistingFormulas(){const e=document.querySelectorAll(".math-inline[copy-text], .math-block[copy-text], .math-inline[data-custom-copy-text], .math-block[data-custom-copy-text]");console.log(`[LatexDownloader] Found ${e.length} formula elements with copy-text`),e.forEach(r=>{const n=r;this.processedElements.has(n)||(this.processedElements.add(n),this.addDownloadButton(n,"inline"))});const t=document.querySelectorAll(".math-inline:not([copy-text]):not([data-custom-copy-text])"),s=document.querySelectorAll(".math-block:not([copy-text]):not([data-custom-copy-text])"),o=document.querySelectorAll(".custom-code-block-container--latex");t.forEach(r=>{const n=r;this.processedElements.has(n)||(this.processedElements.add(n),this.addDownloadButton(n,"inline"))}),s.forEach(r=>{const n=r;this.processedElements.has(n)||(this.processedElements.add(n),this.addDownloadButton(n,"block"))}),o.forEach(r=>{const n=r;this.processedElements.has(n)||(this.processedElements.add(n),this.addLatexCodeDownloadButton(n))})}extractLatexCode(e){const t=e.getAttribute("copy-text")||e.getAttribute("data-custom-copy-text");if(!t)return null;let s=t.match(/\\\(([\s\S]*?)\\\)/);return s||(s=t.match(/\\\[([\s\S]*?)\\\]/),s)?s[1].trim():t.trim()}addDownloadButton(e,t){if(e.querySelector(".dbx-latex-download-btn"))return;const s=this.extractLatexCode(e);if(!s)return;const o=document.createElement("span");o.className="dbx-latex-btn-container",o.style.cssText="display: inline-flex; align-items: center; margin-left: 6px; gap: 4px; vertical-align: middle;";const r=document.createElement("span");r.className="dbx-latex-download-btn",r.innerHTML=`
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="7 10 12 15 17 10"/>
        <line x1="12" y1="15" x2="12" y2="3"/>
      </svg>
    `,r.style.cssText=`
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 22px;
      height: 22px;
      cursor: pointer;
      color: #888;
      border-radius: 4px;
      transition: all 0.2s;
      flex-shrink: 0;
    `,r.addEventListener("mouseenter",()=>{r.style.backgroundColor="#f0f0f0",r.style.color="#333"}),r.addEventListener("mouseleave",()=>{r.style.backgroundColor="transparent",r.style.color="#888"}),r.addEventListener("click",i=>{i.stopPropagation(),this.downloadLatex(s)});const n=document.createElement("span");if(n.className="dbx-latex-copy-btn",n.innerHTML=`
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
      </svg>
    `,n.style.cssText=`
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 22px;
      height: 22px;
      cursor: pointer;
      color: #888;
      border-radius: 4px;
      transition: all 0.2s;
      flex-shrink: 0;
    `,n.addEventListener("mouseenter",()=>{n.style.backgroundColor="#f0f0f0",n.style.color="#333"}),n.addEventListener("mouseleave",()=>{n.style.backgroundColor="transparent",n.style.color="#888"}),n.addEventListener("click",i=>{i.stopPropagation(),this.copyToClipboard(s,n)}),o.appendChild(r),o.appendChild(n),e.parentNode){const i=e.nextSibling;i?e.parentNode.insertBefore(o,i):e.parentNode.appendChild(o)}}addLatexCodeDownloadButton(e){var d;if(e.querySelector(".dbx-latex-code-download-btn"))return;const s=e.querySelector("code");if(!s)return;const o=((d=s.textContent)==null?void 0:d.trim())||"";if(!o)return;const r=e.querySelector(".header-wrapper-Mbk8s6, .header-IAeXdE");if(!r)return;const n=document.createElement("span");n.className="dbx-latex-code-btn-container",n.style.cssText="display: inline-flex; align-items: center; margin-left: 8px; gap: 4px;";const i=document.createElement("span");i.className="dbx-latex-code-download-btn",i.innerHTML=`
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="7 10 12 15 17 10"/>
        <line x1="12" y1="15" x2="12" y2="3"/>
      </svg>
    `,i.style.cssText=`
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 28px;
      height: 28px;
      cursor: pointer;
      color: #666;
      border-radius: 4px;
      transition: all 0.2s;
    `,i.title="Download LaTeX",i.addEventListener("mouseenter",()=>{i.style.backgroundColor="#f0f0f0",i.style.color="#333"}),i.addEventListener("mouseleave",()=>{i.style.backgroundColor="transparent",i.style.color="#666"}),i.addEventListener("click",u=>{u.stopPropagation(),this.downloadLatexCode(o)});const a=document.createElement("span");a.className="dbx-latex-code-copy-btn",a.innerHTML=`
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
      </svg>
    `,a.style.cssText=`
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 28px;
      height: 28px;
      cursor: pointer;
      color: #666;
      border-radius: 4px;
      transition: all 0.2s;
    `,a.title="Copy LaTeX",a.addEventListener("mouseenter",()=>{a.style.backgroundColor="#f0f0f0",a.style.color="#333"}),a.addEventListener("mouseleave",()=>{a.style.backgroundColor="transparent",a.style.color="#666"}),a.addEventListener("click",u=>{u.stopPropagation(),this.copyToClipboard(o,a)}),n.appendChild(i),n.appendChild(a);const l=e.querySelector(".action-ysQCxz");l?l.appendChild(n):r.appendChild(n)}downloadLatex(e){const t=this.wrapLatexDocument(e),s=`formula_${Date.now()}.tex`;this.downloadFile(t,s,"text/plain")}downloadLatexCode(e){const t=this.wrapLatexDocument(e),s=`latex_${Date.now()}.tex`;this.downloadFile(t,s,"text/plain")}async copyToClipboard(e,t){try{await navigator.clipboard.writeText(e);const s=t.innerHTML;t.innerHTML=`
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="20 6 9 17 4 12"/>
        </svg>
      `,t.style.color="#4CAF50",setTimeout(()=>{t.innerHTML=s,t.style.color="#666"},1500)}catch(s){console.error("[LatexDownloader] Copy failed:",s)}}wrapLatexDocument(e){return`% LaTeX Document
% Generated by Better Doubao
% Date: ${new Date().toLocaleString()}

\\documentclass{article}
\\usepackage{amsmath}
\\usepackage{amssymb}

\\begin{document}

${e}

\\end{document}
`}downloadFile(e,t,s){const o=new Blob([e],{type:s}),r=URL.createObjectURL(o),n=document.createElement("a");n.href=r,n.download=t,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(r)}}const V=new be;async function ve(){await w.init(),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{U.init(),W.init(),X.init(),Y.init(),V.init()}):(U.init(),W.init(),X.init(),Y.init(),V.init())}ve();
})()
